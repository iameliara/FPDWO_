<?php
// Koneksi Database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_pep";

// Membuat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ambil id_pengajuan dari URL jika ada
$id_pengajuan = isset($_GET['id_pengajuan']) ? $_GET['id_pengajuan'] : null;

// Proses pengiriman alasan
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_alasan'])) {
    $alasan = $_POST['alasan'];
    // Update alasan di database
    $updateQuery = "UPDATE pengajuan_cuti SET alasan = ? WHERE id_pengajuan = ?";
    $updateStmt = $conn->prepare($updateQuery);
    $updateStmt->bind_param("si", $alasan, $id_pengajuan);
    $updateStmt->execute();
    $updateStmt->close();
}

// Ambil data pengajuan cuti dari database
$query = "SELECT * FROM pengajuan_cuti WHERE id_pengajuan = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id_pengajuan);
$stmt->execute();
$result = $stmt->get_result();

// Cek apakah ada data
if ($result->num_rows > 0) {
    // Ambil data pengajuan cuti
    $data = $result->fetch_assoc();
    
    // Mencari tanda tangan berdasarkan id_pengajuan
    $signatureFile = 'signatures/signature' . $id_pengajuan . '.png'; // Menggunakan format nama file signature(id_pengajuan)
    
    ?>
    
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Laporan Pengajuan Cuti</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <style>
            body {
                background-color: #f8f9fa;
                font-family: Arial, sans-serif;
            }
            .container {
                margin-top: 50px;
                background: white;
                padding: 20px;
                border-radius: 8px;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            }
            h2 {
                text-align: center;
                margin-bottom: 20px;
            }
            .data-label {
                font-weight: bold;
                margin-top: 10px;
            }
            .data-value {
                margin-bottom: 20px;
                border-bottom: 1px solid #e0e0e0;
                padding: 5px 0;
            }
            .signature {
                margin-top: 20px;
                text-align: center;
            }
            .btn-back {
                margin-top: 20px;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h2>Laporan Persetujuan Cuti</h2>
            <div class="data-label">Tanggal Pengajuan:</div>
            <div class="data-value"><?php echo htmlspecialchars($data['tanggal_pengajuan']); ?></div>
            <div class="data-label">Nama:</div>
            <div class="data-value"><?php echo htmlspecialchars($data['nama']); ?></div>
            <div class="data-label">Perihal:</div>
            <div class="data-value"><?php echo htmlspecialchars($data['perihal']); ?></div>
            <div class="data-label">Jenis Surat:</div>
            <div class="data-value"><?php echo htmlspecialchars($data['jenis_surat']); ?></div>
            <div class="data-label">Nomor Surat:</div>
            <div class="data-value"><?php echo htmlspecialchars($data['nomor_surat']); ?></div>
            <div class="data-label">Tanggal Mulai Cuti:</div>
            <div class="data-value"><?php echo htmlspecialchars($data['tanggal_mulai_cuti']); ?></div>
            <div class="data-label">Tanggal Akhir Cuti:</div>
            <div class="data-value"><?php echo htmlspecialchars($data['tanggal_akhir_cuti']); ?></div>
            <div class="data-label">Lama Cuti:</div>
            <div class="data-value"><?php echo htmlspecialchars($data['lama_cuti']); ?></div>
            <div class="data-label">Bidang Penerima:</div>
            <div class="data-value"><?php echo htmlspecialchars($data['bidang_penerima']); ?></div>
            <div class="data-label">Nama Penerima:</div>
            <div class="data-value"><?php echo htmlspecialchars($data['nama_penerima']); ?></div>
            <div class="data-label">Keterangan:</div>
            <div class="data-value"><?php echo htmlspecialchars($data['keterangan']); ?></div>
            <div class="data-label">Alasan:</div>
            <div class="data-value"><?php echo htmlspecialchars($data['alasan']); ?></div>

            <!-- Input untuk alasan -->
            <form method="POST">
                <div class="form-group">
                    <label for="alasan">Masukkan Alasan:</label>
                    <textarea id="alasan" name="alasan" class="form-control" rows="3"><?php echo htmlspecialchars($data['alasan']); ?></textarea>
                </div>
                <button type="submit" name="update_alasan" class="btn btn-success">Update Alasan</button>
            </form>

            <!-- Menampilkan tanda tangan berdasarkan id_pengajuan -->
            <?php if (file_exists($signatureFile)): ?>
                <div class="signature">
                    <img src="<?php echo $signatureFile; ?>" alt="Tanda Tangan" style="max-width: 500px; height: auto;">
                </div>
            <?php else: ?>
                <div class="signature">Tanda tangan tidak ditemukan.</div>
            <?php endif; ?>

            <a href="javascript:history.back()" class="btn btn-primary btn-back">Kembali</a>
        </div>

        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    </body>
    </html>
    
    <?php
} else {
    echo "Data tidak ditemukan.";
}

$stmt->close();
$conn->close();
?>
