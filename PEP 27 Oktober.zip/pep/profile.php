<?php
session_start();

// Pastikan user sudah login
if (!isset($_SESSION['session_username'])) {
    header("Location: index.html");
    exit();
}

// Koneksi ke database
$servername = "localhost";
$db_username = "root";
$password = "";
$dbname = "db_pep";

$conn = new mysqli($servername, $db_username, $password, $dbname);

// Cek koneksi ke database
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ambil username dari session
$username = $_SESSION['session_username'];

// Ambil data pengguna berdasarkan username dari sesi
$sql = $conn->prepare("SELECT * FROM user WHERE username = ?");
$sql->bind_param("s", $username);
$sql->execute();
$result = $sql->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $nama = htmlspecialchars($row['nama']);
} else {
    echo "User not found.";
    exit();
}

// Jika form ganti password dikirim
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['change_password'])) {
    $old_password = $_POST['old_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    // Validasi password lama
    if (password_verify($old_password, $row['password'])) {
        // Pastikan password baru dan konfirmasi cocok
        if ($new_password === $confirm_password) {
            // Enkripsi password baru
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

            // Update password di database
            $update_sql = $conn->prepare("UPDATE user SET password = ? WHERE username = ?");
            $update_sql->bind_param("ss", $hashed_password, $username);

            if ($update_sql->execute()) {
                echo "<script>alert('Password berhasil diubah!'); window.location.href='profile.php';</script>";
            } else {
                echo "<script>alert('Error saat mengubah password!');</script>";
            }
        } else {
            echo "<script>alert('Password baru dan konfirmasi tidak cocok!');</script>";
        }
    } else {
        echo "<script>alert('Password lama salah!');</script>";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Pengguna</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-primary text-white text-center">
                        <h3>Profil Pengguna</h3>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">Nama: <?php echo $nama; ?></h5>
                        <a href="logoutuser.php" class="btn btn-danger mb-3">Logout</a>

                        <!-- Form Ganti Password -->
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label for="old_password" class="form-label">Password Lama</label>
                                <input type="password" class="form-control" id="old_password" name="old_password" required>
                            </div>
                            <div class="mb-3">
                                <label for="new_password" class="form-label">Password Baru</label>
                                <input type="password" class="form-control" id="new_password" name="new_password" required>
                            </div>
                            <div class="mb-3">
                                <label for="confirm_password" class="form-label">Konfirmasi Password Baru</label>
                                <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                            </div>
                            <button type="submit" name="change_password" class="btn btn-success">Ganti Password</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
