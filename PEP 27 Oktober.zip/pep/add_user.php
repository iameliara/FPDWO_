<?php
session_start();

// Pastikan user sudah login
if (!isset($_SESSION['session_username'])) {
    header("Location: index.html");
    exit();
}

// Koneksi ke database
$servername = "localhost";
$db_username = "root";
$password = "";
$dbname = "db_pep";

$conn = new mysqli($servername, $db_username, $password, $dbname);

// Cek koneksi ke database
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Jika form tambah user dikirim
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_user'])) {
    $username = $_POST['username'];
    $nama = $_POST['nama'];
    $password = $_POST['password']; // Tidak dienkripsi

    // Insert ke tabel user
    $sql = $conn->prepare("INSERT INTO user (username, password, nama) VALUES (?, ?, ?)");
    $sql->bind_param("sss", $username, $password, $nama);

    if ($sql->execute()) {
        echo "<script>
                alert('User berhasil ditambahkan!');
                document.getElementById('addUserForm').reset(); // Reset form
              </script>";
    } else {
        echo "<script>alert('Error: Gagal menambahkan user!');</script>";
    }
}

$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah User</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-success text-white text-center">
                        <h3>Tambah User Baru</h3>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="" id="addUserForm">
                            <div class="mb-3">
                                <label for="username" class="form-label">Username</label>
                                <input type="text" class="form-control" id="username" name="username" required>
                            </div>
                            <div class="mb-3">
                                <label for="nama" class="form-label">Nama Lengkap</label>
                                <input type="text" class="form-control" id="nama" name="nama" required>
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" class="form-control" id="password" name="password" required>
                            </div>
                            <button type="submit" name="add_user" class="btn btn-primary w-100">Tambah User</button>
                        </form>
                    </div>
                </div>
                <a href="admin_dashboard.php" class="btn btn-secondary mt-3 w-100">Kembali ke Dashboard</a>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Reset form setelah user berhasil ditambahkan
        if (window.history.replaceState) {
            window.history.replaceState(null, null, window.location.href);
        }
    </script>
</body>
</html>
