<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.html");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_pengaduan";

// Buat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h2 class="mt-2">Admin Dashboard</h2>
        <a href="logout.php" class="btn btn-danger mb-3">Logout</a>

        <!-- News Form -->
        <h3>Add News</h3>
        <form action="add_news.php" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="title">Title:</label>
                <input type="text" class="form-control" id="title" name="title" required>
            </div>
            <div class="form-group">
                <label for="link">Link:</label>
                <input type="text" class="form-control" id="link" name="link" required>
            </div>
            <div class="form-group">
                <label for="cover_image">Cover Image:</label>
                <input type="file" class="form-control" id="cover_image" name="cover_image" required>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>

        <!-- News List -->
        <h3 class="mt-5">News List</h3>
        <div class="row">
            <?php
            $result = $conn->query("SELECT * FROM news ORDER BY created_at DESC");
            while ($row = $result->fetch_assoc()) { ?>
                <div class="col-md-4 mb-3">
                    <div class="card">
                        <img class="card-img-top" src="uploads/<?php echo $row['cover_image']; ?>" alt="<?php echo $row['title']; ?>">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $row['title']; ?></h5>
                            <a href="<?php echo $row['link']; ?>" class="btn btn-primary">Read More</a>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>
</body>
</html>

<?php
$conn->close();
?>
