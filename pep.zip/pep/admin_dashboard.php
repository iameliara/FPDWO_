<?php
session_start();

// Pastikan user sudah login
if (!isset($_SESSION['session_username'])) {
    header("Location: login.html");
    exit();
}
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
ini_set('display_errors', '0');

// Koneksi ke database
$servername = "localhost";
$db_username = "root"; // username untuk koneksi database
$password = "";
$dbname = "db_pep";

$conn = new mysqli($servername, $db_username, $password, $dbname);

// Cek koneksi ke database
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_SESSION['session_username'];
// Log visit
$sql = "INSERT INTO kunjungan (timestamp) VALUES (NOW())";
$conn->query($sql);

// Fetch data for charts
$sql_kunjungan = "SELECT DATE(timestamp) as date, COUNT(*) as count FROM kunjungan GROUP BY DATE(timestamp)";
$kunjungan_result = $conn->query($sql_kunjungan);
$kunjungan_data = [];
while($row = $kunjungan_result->fetch_assoc()) {
    $kunjungan_data[] = $row;
}


// Handle Event Management (Add Event)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_event'])) {
    $event_name = $_POST['event_name'];
    $event_date = $_POST['event_date'];
    $event_time = $_POST['event_time'];
    $description = $_POST['description'];

    $sql = "INSERT INTO events (event_name, event_date, event_time, description) 
            VALUES ('$event_name', '$event_date', '$event_time', '$description')";
    $conn->query($sql);
}

// Handle News Management (Add/Edit/Delete News)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_news'])) {
        // Add news
        $title = $_POST['title'];
        $link = $_POST['link'];
        $target_dir = "uploads/";
        $temp_file = $_FILES["cover_image"]["tmp_name"];
        $target_file = $target_dir . uniqid() . ".jpg";

        $standard_width = 800;
        $standard_height = 600;

        if (resizeAndCropImage($temp_file, $target_file, $standard_width, $standard_height)) {
            $cover_image = basename($target_file);
            $sql = "INSERT INTO news (title, link, cover_image) VALUES ('$title', '$link', '$cover_image')";
            $conn->query($sql);
        }
    } elseif (isset($_POST['edit_news'])) {
        // Edit news
        $id = $_POST['id'];
        $title = $_POST['title'];
        $link = $_POST['link'];
        $sql = "UPDATE news SET title='$title', link='$link' WHERE id=$id";
        if (!empty($_FILES["cover_image"]["name"])) {
            $target_file = "uploads/" . basename($_FILES["cover_image"]["name"]);
            move_uploaded_file($_FILES["cover_image"]["tmp_name"], $target_file);
            $cover_image = basename($_FILES["cover_image"]["name"]);
            $sql = "UPDATE news SET title='$title', link='$link', cover_image='$cover_image' WHERE id=$id";
        }
        $conn->query($sql);
    }
}

if (isset($_GET['delete'])) {
    // Delete news
    $id = $_GET['delete'];
    $sql = "DELETE FROM news WHERE id=$id";
    $conn->query($sql);
}

// Handle Pustaka Management (Add/Edit/Delete Pustaka)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_pustaka']) || isset($_POST['edit_pustaka'])) {
        $judul = $_POST['judul'];
        $link = $_POST['link'];
        $kategori = $_POST['kategori'];
        $id = isset($_POST['id']) ? $_POST['id'] : null;

        $target_dir = "uploads/";
        $temp_file = $_FILES["cover_image"]["tmp_name"];
        $target_file = $target_dir . uniqid() . ".jpg";

        $standard_width = 800;
        $standard_height = 600;

        if (resizeAndCropImage($temp_file, $target_file, $standard_width, $standard_height)) {
            $cover_image = basename($target_file);

            if ($id) {
                // Edit existing pustaka
                $sql = "UPDATE pustaka SET judul='$judul', link='$link', kategori='$kategori', cover_image='$cover_image' WHERE id=$id";
            } else {
                // Add new pustaka
                $sql = "INSERT INTO pustaka (judul, link, cover_image, kategori) VALUES ('$judul', '$link', '$cover_image', '$kategori')";
            }
            $conn->query($sql);
        }
    }
}

if (isset($_GET['delete_pustaka'])) {
    $id = $_GET['delete_pustaka'];
    $sql = "DELETE FROM pustaka WHERE id=$id";
    $conn->query($sql);
}

if (isset($_GET['edit_pustaka'])) {
    $id = $_GET['edit_pustaka'];
    $result = $conn->query("SELECT * FROM pustaka WHERE id=$id");
    $edit_pustaka = $result->fetch_assoc();
}

// Handle Galeri Management (Add/Edit/Delete Galeri)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_galeri']) || isset($_POST['edit_galeri'])) {
        $judul = $_POST['judul_galeri'];
        $link = $_POST['link_galeri'];
        $id = isset($_POST['id']) ? $_POST['id'] : null;

        if (isset($_FILES["gambar_galeri"]) && $_FILES["gambar_galeri"]["error"] == UPLOAD_ERR_OK) {
            $target_dir = "uploads/";
            $file_extension = strtolower(pathinfo($_FILES["gambar_galeri"]["name"], PATHINFO_EXTENSION));
            $target_file = $target_dir . uniqid() . "." . $file_extension;

            $allowed_types = array('jpg', 'jpeg', 'png', 'gif');
            if (in_array($file_extension, $allowed_types)) {
                if (resizeAndCropImage($_FILES["gambar_galeri"]["tmp_name"], $target_file, 800, 600)) {
                    $gambar = basename($target_file);

                    if ($id) {
                        // Edit existing galeri
                        $sql = "UPDATE galeri SET judul='$judul', link='$link', gambar='$gambar' WHERE id=$id";
                    } else {
                        // Add new galeri
                        $sql = "INSERT INTO galeri (judul, link, gambar) VALUES ('$judul', '$link', '$gambar')";
                    }

                    if ($conn->query($sql) === TRUE) {
                        echo "<script>alert('Data berhasil disimpan');</script>";
                    } else {
                        echo "<script>alert('Error: " . $conn->error . "');</script>";
                    }
                } else {
                    echo "<script>alert('Gagal mengupload file');</script>";
                }
            } else {
                echo "<script>alert('Hanya file JPG, JPEG, PNG, dan GIF yang diizinkan');</script>";
            }
        } else {
            // Jika tidak ada file yang diunggah, hanya update judul dan link
            if ($id) {
                $sql = "UPDATE galeri SET judul='$judul', link='$link' WHERE id=$id";
                if ($conn->query($sql) === TRUE) {
                    echo "<script>alert('Data berhasil diperbarui');</script>";
                } else {
                    echo "<script>alert('Error: " . $conn->error . "');</script>";
                }
            } else {
                echo "<script>alert('Silakan pilih gambar untuk ditambahkan');</script>";
            }
        }
    }
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = isset($_POST['id']) ? $_POST['id'] : '';
    $nama_tautan = $_POST['nama_tautan'];
    $link = $_POST['link'];

    if (isset($_POST['edit_tautan'])) {
        // Update tautan
        $stmt = $conn->prepare("UPDATE tautan SET nama_tautan=?, link=? WHERE id=?");
        $stmt->bind_param("ssi", $nama_tautan, $link, $id);
        $stmt->execute();
        $stmt->close();
    } else {
        // Tambah tautan
        $stmt = $conn->prepare("INSERT INTO tautan (nama_tautan, link) VALUES (?, ?)");
        $stmt->bind_param("ss", $nama_tautan, $link);
        $stmt->execute();
        $stmt->close();
    }
}

// Proses edit tautan
$edit_tautan = null;
if (isset($_GET['edit_tautan'])) {
    $id_edit = $_GET['edit'];
    $result = $conn->query("SELECT * FROM tautan WHERE id='$id_edit'");
    $edit_tautan = $result->fetch_assoc();
}

// Proses hapus tautan
if (isset($_GET['delete_tautan'])) {
    $id = $_GET['delete_tautan'];
    $stmt = $conn->prepare("DELETE FROM tautan WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: admin_dashboard.php");
    exit();
}
if (isset($_POST['add_aturan'])) {
    $nama_aturan = $_POST['nama_aturan'];
    $link = $_POST['link'];

    $stmt = $conn->prepare("INSERT INTO dasar_aturan (nama_aturan, link) VALUES (?, ?)");
    $stmt->bind_param("ss", $nama_aturan, $link);
    $stmt->execute();
    header("Location: admin_dashboard.php");
    exit();
}

// Edit data dasar_aturan
if (isset($_POST['edit_aturan'])) {
    $id = $_POST['id'];
    $nama_aturan = $_POST['nama_aturan'];
    $link = $_POST['link'];

    $stmt = $conn->prepare("UPDATE dasar_aturan SET nama_aturan = ?, link = ? WHERE id = ?");
    $stmt->bind_param("ssi", $nama_aturan, $link, $id);
    $stmt->execute();
    header("Location: admin_dashboard.php");
    exit();
}

// Hapus data dasar_aturan
if (isset($_GET['delete_aturan'])) {
    $id = $_GET['delete_aturan'];
    $stmt = $conn->prepare("DELETE FROM dasar_aturan WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: admin_dashboard.php");
    exit();
}

// Mendapatkan data untuk pengeditan
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $result = $conn->query("SELECT * FROM dasar_aturan WHERE id = $id");
    $edit_aturan = $result->fetch_assoc();
}

if (isset($_GET['delete_galeri'])) {
    $id = $_GET['delete_galeri'];
    $stmt = $conn->prepare("DELETE FROM galeri WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: admin_dashboard.php");
    exit();
}

if (isset($_GET['edit_galeri'])) {
    $id = $_GET['edit_galeri'];
    $result = $conn->query("SELECT * FROM galeri WHERE id=$id");
    $edit_galeri = $result->fetch_assoc();
}

function resizeAndCropImage($sourcePath, $targetPath, $targetWidth, $targetHeight) {
    return move_uploaded_file($sourcePath, $targetPath);
}

if (isset($_FILES["gambar_galeri"]) && $_FILES["gambar_galeri"]["error"] !== UPLOAD_ERR_OK) {
    $upload_errors = array(
        UPLOAD_ERR_INI_SIZE => "The uploaded file exceeds the upload_max_filesize directive in php.ini",
        UPLOAD_ERR_FORM_SIZE => "The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form",
        UPLOAD_ERR_PARTIAL => "The uploaded file was only partially uploaded",
        UPLOAD_ERR_NO_FILE => "No file was uploaded",
        UPLOAD_ERR_NO_TMP_DIR => "Missing a temporary folder",
        UPLOAD_ERR_CANT_WRITE => "Failed to write file to disk",
        UPLOAD_ERR_EXTENSION => "A PHP extension stopped the file upload"
    );
    $error_message = isset($upload_errors[$_FILES["gambar_galeri"]["error"]]) ? $upload_errors[$_FILES["gambar_galeri"]["error"]] : "Unknown upload error";
    echo "<script>alert('Upload error: " . $error_message . "');</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="Description" content="Signature Pad for Function Signature" />
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/signature_pad/2.3.2/signature_pad.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="jSignature/jquery.js"></script>
    <script src="jSignature/jquery.min.js"></script>
    <script src="jSignature/modernizr.js"></script>
    <style>
        canvas {
            border: 1px solid #ccc;
            border-radius: 0.5rem;
            width: 100%;
            height: 400px;
        }

        .chart-container {
            position: relative;
            height: 300px;
            width: 100%;
        }
        .chart-title {
            text-align: center;
            font-weight: bold;
            margin-bottom: 10px;
        }
        .nav-pills .nav-link.active {
            background-color: #007bff;
        }
        .card-img-top {
            width: 100%;
            height: 200px; /* Sesuaikan dengan rasio yang Anda inginkan */
            object-fit: cover;
        }
        .signature-pad {
            border: 1px solid #000;
            touch-action: none; /* Mencegah scrolling saat menggambar di touchscreen */
            cursor: crosshair; /* Mengubah kursor saat menggambar */
        }
        .signature-modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5); /* Blur effect */
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1000; /* Ensure it appears above other content */
        }
        .modal-content {
            background: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
            position: relative;
            width: 450px; /* Width of the modal */
            text-align: center; /* Center the content */
        }
        .signature-pad-full {
            width: 100%; /* Make canvas responsive */
            height: auto;
        }
        .button-group {
            margin-top: 10px;
            display: flex;
            justify-content: space-between;
        }
        
        
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <nav class="col-md-2 d-none d-md-block bg-light sidebar">
                <div class="sidebar-sticky">
                    <h2 class="mt-2">Admin Dashboard</h2>
                    <ul class="nav flex-column nav-pills" id="v-pills-tab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="v-pills-home-tab" data-toggle="pill" href="#v-pills-home" role="tab">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="v-pills-events-tab" data-toggle="pill" href="#v-pills-events" role="tab">Manage Agenda</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="v-pills-news-tab" data-toggle="pill" href="#v-pills-news" role="tab">Manage Berita</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="v-pills-dasar-aturan-tab" data-toggle="pill" href="#v-pills-dasar-aturan" role="tab">Manage Dasar Aturan</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="v-pills-pustaka-tab" data-toggle="pill" href="#v-pills-pustaka" role="tab">Manage Pustaka</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="v-pills-tautan-tab" data-toggle="pill" href="#v-pills-tautan" role="tab">Manage Tautan</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="v-pills-galeri-tab" data-toggle="pill" href="#v-pills-galeri" role="tab">Manage Galeri</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="v-pills-cuti-tab" data-toggle="pill" href="#v-pills-cuti" role="tab">Manage Cuti</a>
                        </li>
                    </ul>
                    <a href="logout.php" class="btn btn-danger mt-3">Logout</a>
                </div>
            </nav>

            <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
                <div class="tab-content" id="v-pills-tabContent">
                    <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel">
                        <h2>Dashboard Overview</h2>
                        <div class="row mt-4">
                <div class="col-md-8">
                    <div class="chart-title">Data Kunjungan</div>
                    <div class="chart-container">
                        <canvas id="barChart"></canvas>
                    </div>
                </div>

                <div class="col-md-4 text-center">
                    <h5 class="mt-3">Tambah User Baru</h5>
                    <p>Tekan tombol di bawah untuk menambah user baru ke sistem.</p>
                    <a href="add_user.php" class="btn btn-primary btn-lg mt-2">Tambah User</a>
                </div>
            </div>
        </div>
                    
                    <div class="tab-pane fade" id="v-pills-events" role="tabpanel">
                        <h2>Manage Agenda</h2>
                        <form action="admin_dashboard.php" method="POST">
                            <div class="form-group">
                                <label for="event_name">Nama Kegiatan:</label>
                                <input type="text" class="form-control" id="event_name" name="event_name" required>
                            </div>
                            <div class="form-group">
                                <label for="event_date">Tanggal:</label>
                                <input type="date" class="form-control" id="event_date" name="event_date" required>
                            </div>
                            <div class="form-group">
                                <label for="event_time">Waktu:</label>
                                <input type="time" class="form-control" id="event_time" name="event_time" required>
                            </div>
                            <div class="form-group">
                                <label for="description">Deskripsi Kegiatan:</label>
                                <textarea class="form-control" id="description" name="description" rows="4" required></textarea>
                            </div>
                            <button type="submit" name="add_event" class="btn btn-primary">Tambah Agenda</button>
                        </form>
                    </div>
                    
                    <div class="tab-pane fade" id="v-pills-news" role="tabpanel">
                        <h2>Manage Berita</h2>
                        <form action="admin_dashboard.php" method="POST" enctype="multipart/form-data">
                            <input type="hidden" name="id" value="<?php echo isset($edit_news['id']) ? $edit_news['id'] : ''; ?>">
                            <div class="form-group">
                                <label for="title">Judul:</label>
                                <input type="text" class="form-control" id="title" name="title" value="<?php echo isset($edit_news['title']) ? $edit_news['title'] : ''; ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="link">Link:</label>
                                <input type="text" class="form-control" id="link" name="link" value="<?php echo isset($edit_news['link']) ? $edit_news['link'] : ''; ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="cover_image">Foto Cover:</label>
                                <input type="file" class="form-control" id="cover_image" name="cover_image">
                            </div>
                            <button type="submit" name="<?php echo isset($edit_news) ? 'edit_news' : 'add_news'; ?>" class="btn btn-primary">Tambah Berita</button>
                        </form>
                        
                        <h3 class="mt-4">Berita</h3>
                        <div class="row">
                            <?php
                            $news_result = $conn->query("SELECT * FROM news ORDER BY created_at DESC");
                            while ($row = $news_result->fetch_assoc()) { ?>
                                <div class="col-md-4 mb-3">
                                    <div class="card">
                                        <img class="card-img-top" src="uploads/<?php echo $row['cover_image']; ?>" alt="<?php echo $row['title']; ?>">
                                        <div class="card-body">
                                            <h5 class="card-title"><?php echo $row['title']; ?></h5>
                                            <a href="<?php echo $row['link']; ?>" class="btn btn-primary btn-sm">Baca</a>
                                            <a href="admin_dashboard.php?delete=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm">Hapus</a>
                                        </div>
                                    </div>
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="v-pills-dasar-aturan" role="tabpanel">
                        <h2>Manage Dasar Aturan</h2>
                        <!-- Form untuk Tambah/Edit Dasar Aturan -->
                        <form action="admin_dashboard.php" method="POST">
                            <input type="hidden" name="id" value="<?php echo isset($edit_aturan['id']) ? $edit_aturan['id'] : ''; ?>">
                            
                            <div class="form-group">
                                <label for="nama_aturan">Nama Aturan:</label>
                                <input type="text" class="form-control" id="nama_aturan" name="nama_aturan" 
                                    value="<?php echo isset($edit_aturan['nama_aturan']) ? $edit_aturan['nama_aturan'] : ''; ?>" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="link">Link:</label>
                                <input type="text" class="form-control" id="link" name="link" 
                                    value="<?php echo isset($edit_aturan['link']) ? $edit_aturan['link'] : ''; ?>" required>
                            </div>
                            
                            <button type="submit" name="<?php echo isset($edit_aturan) ? 'edit_aturan' : 'add_aturan'; ?>" class="btn btn-primary">
                                <?php echo isset($edit_aturan) ? 'Update' : 'Add'; ?>
                            </button>
                        </form>
                        
                        <!-- Daftar Dasar Aturan -->
                        <h3 class="mt-4">Daftar Dasar Aturan</h3>
                        <div class="row">
                            <?php
                            // Ambil data dasar_aturan dari database
                            $aturan_result = $conn->query("SELECT * FROM dasar_aturan ORDER BY id DESC");
                            while ($row = $aturan_result->fetch_assoc()) { ?>
                                <div class="col-md-4 mb-3">
                                    <div class="card">
                                        <div class="card-body">
                                            <h5 class="card-title"><?php echo $row['nama_aturan']; ?></h5>
                                            <a href="<?php echo $row['link']; ?>" class="btn btn-primary btn-sm" target="_blank">Lihat</a>
                                            <a href="admin_dashboard.php?delete_aturan=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm">Hapus</a>
                                        </div>
                                    </div>
                                </div>
                            <?php } ?>
                        </div>
                    </div>

                    <div class="tab-pane fade" id="v-pills-pustaka" role="tabpanel">
                        <h2>Manage Pustaka</h2>
                        <form action="admin_dashboard.php" method="POST" enctype="multipart/form-data">
                            <input type="hidden" name="id" value="<?php echo isset($edit_pustaka['id']) ? $edit_pustaka['id'] : ''; ?>">
                            <div class="form-group">
                                <label for="judul">Judul Materi:</label>
                                <input type="text" class="form-control" id="judul" name="judul" value="<?php echo isset($edit_pustaka['judul']) ? $edit_pustaka['judul'] : ''; ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="link">Link Materi:</label>
                                <input type="url" class="form-control" id="link" name="link" value="<?php echo isset($edit_pustaka['link']) ? $edit_pustaka['link'] : ''; ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="cover_image">Cover Materi:</label>
                                <input type="file" class="form-control" id="cover_image" name="cover_image">
                            </div>
                            <div class="form-group">
                                <label for="kategori">Kategori:</label>
                                <select class="form-control" id="kategori" name="kategori" required>
                                    <option value="">Pilih Kategori</option>
                                    <option value="Pendaftaran" <?php echo (isset($edit_pustaka['kategori']) && $edit_pustaka['kategori'] == 'Pendaftaran') ? 'selected' : ''; ?>>Pendaftaran</option>
                                    <option value="Ekstentifikasi" <?php echo (isset($edit_pustaka['kategori']) && $edit_pustaka['kategori'] == 'Ekstentifikasi') ? 'selected' : ''; ?>>Ekstentifikasi</option>
                                    <option value="Penilaian" <?php echo (isset($edit_pustaka['kategori']) && $edit_pustaka['kategori'] == 'Penilaian') ? 'selected' : ''; ?>>Penilaian</option>
                                </select>
                            </div>
                            <button type="submit" name="<?php echo isset($edit_pustaka) ? 'edit_pustaka' : 'add_pustaka'; ?>" class="btn btn-primary">Tambah</button>
                        </form>
                        
                        <h3 class="mt-4">Daftar Pustaka</h3>
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Judul</th>
                                        <th>Kategori</th>
                                        <th>Link</th>
                                        <th>Cover</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $pustaka_result = $conn->query("SELECT * FROM pustaka ORDER BY created_at DESC");
                                    while ($row = $pustaka_result->fetch_assoc()) { ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($row['judul']); ?></td>
                                            <td><?php echo htmlspecialchars($row['kategori']); ?></td>
                                            <td><a href="<?php echo htmlspecialchars($row['link']); ?>" target="_blank">Lihat</a></td>
                                            <td><img src="uploads/<?php echo htmlspecialchars($row['cover_image']); ?>" alt="<?php echo htmlspecialchars($row['judul']); ?>" style="width: 50px; height: auto;"></td>
                                            <td>
                                                <a href="admin_dashboard.php?delete_pustaka=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus pustaka ini?')">Hapus</a>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="v-pills-tautan" role="tabpanel"> <!-- Mengganti id dari aturan menjadi tautan -->
                    <h2>Manage Tautan</h2> <!-- Mengganti "Aturan" menjadi "Tautan" -->
                    <!-- Form untuk Tambah/Edit Dasar Tautan -->
                    <form action="admin_dashboard.php" method="POST">
                        <input type="hidden" name="id" value="<?php echo isset($edit_tautan['id']) ? $edit_tautan['id'] : ''; ?>">
                        
                        <div class="form-group">
                            <label for="nama_tautan">Nama Tautan:</label> <!-- Mengganti "Aturan" menjadi "Tautan" -->
                            <input type="text" class="form-control" id="nama_tautan" name="nama_tautan" 
                                value="<?php echo isset($edit_tautan['nama_tautan']) ? $edit_tautan['nama_tautan'] : ''; ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="link">Link:</label>
                            <input type="text" class="form-control" id="link" name="link" 
                                value="<?php echo isset($edit_tautan['link']) ? $edit_tautan['link'] : ''; ?>" required>
                        </div>
                        
                        <button type="submit" name="<?php echo isset($edit_tautan) ? 'edit_tautan' : 'add_tautan'; ?>" class="btn btn-primary">
                            <?php echo isset($edit_tautan) ? 'Update' : 'Add'; ?>
                        </button>
                    </form>
                    
                    <!-- Daftar Dasar Tautan -->
                    <h3 class="mt-4">Daftar Tautan</h3> <!-- Mengganti "Aturan" menjadi "Tautan" -->
                    <div class="row">
                        <?php
                        // Ambil data dasar_tautan dari database
                        $tautan_result = $conn->query("SELECT * FROM tautan ORDER BY id DESC");
                        while ($row = $tautan_result->fetch_assoc()) { ?>
                            <div class="col-md-4 mb-3">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title">
                                            <a href="<?php echo $row['link']; ?>" target="_blank"><?php echo $row['nama_tautan']; ?></a> <!-- Menjadikan nama tautan sebagai tautan -->
                                        </h5>
                                        <a href="admin_dashboard.php?delete_tautan=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm">Hapus</a>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                    </div>
                </div>
                    <div class="tab-pane fade" id="v-pills-galeri" role="tabpanel">
                        <h2>Manage Galeri</h2>
                        <form action="admin_dashboard.php" method="POST" enctype="multipart/form-data">
                            <input type="hidden" name="id" value="<?php echo isset($edit_galeri['id']) ? $edit_galeri['id'] : ''; ?>">
                            <div class="form-group">
                                <label for="judul_galeri">Judul:</label>
                                <input type="text" class="form-control" id="judul_galeri" name="judul_galeri" value="<?php echo isset($edit_galeri['judul']) ? $edit_galeri['judul'] : ''; ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="link_galeri">Link:</label>
                                <input type="url" class="form-control" id="link_galeri" name="link_galeri" value="<?php echo isset($edit_galeri['link']) ? $edit_galeri['link'] : ''; ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="gambar_galeri">Gambar:</label>
                                <input type="file" class="form-control" id="gambar_galeri" name="gambar_galeri" accept="image/jpeg,image/png,image/gif" <?php echo isset($edit_galeri) ? '' : 'required'; ?>>
                                <small class="form-text text-muted">Hanya file JPG, JPEG, PNG, dan GIF yang diizinkan.</small>
                            </div>
                            <button type="submit" name="<?php echo isset($edit_galeri) ? 'edit_galeri' : 'add_galeri'; ?>" class="btn btn-primary">Tambah</button>
                        </form>
                        
                        <h3 class="mt-4">Daftar Galeri</h3>
                        <div class="row">
                            <?php
                            $galeri_result = $conn->query("SELECT * FROM galeri ORDER BY created_at DESC");
                            if (!$galeri_result) {
                                echo "<script>alert('Error: " . $conn->error . "');</script>";
                            } else {
                                echo "<script>console.log('Jumlah data: " . $galeri_result->num_rows . "');</script>";
                                if ($galeri_result->num_rows > 0) {
                                    while ($row = $galeri_result->fetch_assoc()) { ?>
                                        <div class="col-md-4 mb-3">
                                            <div class="card">
                                                <img class="card-img-top" src="uploads/<?php echo htmlspecialchars($row['gambar']); ?>" alt="<?php echo htmlspecialchars($row['judul']); ?>">
                                                <div class="card-body">
                                                    <h5 class="card-title"><?php echo htmlspecialchars($row['judul']); ?></h5>
                                                    <a href="<?php echo htmlspecialchars($row['link']); ?>" class="btn btn-primary btn-sm" target="_blank">Lihat</a>
                                                    <a href="admin_dashboard.php?delete_galeri=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus item galeri ini?')">Hapus</a>
                                                </div>
                                            </div>
                                        </div>
                                    <?php }
                                } else {
                                    echo "<p>Tidak ada data galeri.</p>";
                                }
                            }
                            ?>
                        </div>
                    </div>
                    <!-- Manage Cuti Section -->
                    <div class="tab-pane fade" id="v-pills-cuti" role="tabpanel">
                        <h2>Manage Cuti</h2>
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Tanggal Pengajuan</th>
                                        <th>Nama</th>
                                        <th>Perihal</th>
                                        <th>Jenis Surat</th>
                                        <th>Nomor Surat</th>
                                        <th>Tanggal Mulai Cuti</th>
                                        <th>Tanggal Akhir Cuti</th>
                                        <th>Lama Cuti</th>
                                        <th>Bidang Penerima</th>
                                        <th>Nama Penerima</th>
                                        <th>Keterangan</th>
                                        <th>Laporan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $cuti_result = $conn->query("SELECT * FROM pengajuan_cuti ORDER BY tanggal_pengajuan DESC");
                                    if ($cuti_result === false) {
                                        echo "Error: " . $conn->error;
                                    } else {
                                        echo "Jumlah data: " . $cuti_result->num_rows;
                                    }
                                    while ($row = $cuti_result->fetch_assoc()) { ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($row['tanggal_pengajuan']); ?></td>
                                            <td><?php echo htmlspecialchars($row['nama']); ?></td>
                                            <td><?php echo htmlspecialchars($row['perihal']); ?></td>
                                            <td><?php echo htmlspecialchars($row['jenis_surat']); ?></td>
                                            <td><?php echo htmlspecialchars($row['nomor_surat']); ?></td>
                                            <td><?php echo htmlspecialchars($row['tanggal_mulai_cuti']); ?></td>
                                            <td><?php echo htmlspecialchars($row['tanggal_akhir_cuti']); ?></td>
                                            <td><?php echo htmlspecialchars($row['lama_cuti']); ?></td>
                                                <td>
                                                    <!-- Dropdown untuk Bidang Penerima -->
                                                    <form action="statuscuti.php" method="post" enctype="multipart/form-data">
                                                     <input type="hidden" name="id_pengajuan" value="<?php echo $row['id_pengajuan']; ?>">

                                                    <select class="form-control" name="bidang_penerima" id="bidang_penerima_<?php echo $row['id_pengajuan']; ?>" onchange="updateNamaPenerima(<?php echo $row['id_pengajuan']; ?>)" required>
                                                        <option value="">Pilih Bidang Penerima</option>
                                                        <option value="Bidang PEP" <?php echo ($row['bidang_penerima'] == 'Bidang PEP') ? 'selected' : ''; ?>>Bidang PEP</option>
                                                        <option value="Bidang Sekretaris Kanwil" <?php echo ($row['bidang_penerima'] == 'Bidang Sekretaris Kanwil') ? 'selected' : ''; ?>>Bidang Sekretaris Kanwil</option>
                                                        <option value="Bidang Umum" <?php echo ($row['bidang_penerima'] == 'Bidang Umum') ? 'selected' : ''; ?>>Bidang Umum</option>
                                                    </select>
                                                </td>

                                                <!-- Dropdown untuk Nama Penerima -->
                                                <td>
                                                    <select class="form-control mt-2" name="nama_penerima" id="nama_penerima_<?php echo $row['id_pengajuan']; ?>" required>
                                                        <option value="">Pilih Nama Penerima</option>
                                                        <option value="Sari" <?php echo ($row['nama_penerima'] == 'Sari') ? 'selected' : ''; ?>>Sari</option>
                                                        <option value="Budi" <?php echo ($row['nama_penerima'] == 'Budi') ? 'selected' : ''; ?>>Budi</option>
                                                        <option value="Andi" <?php echo ($row['nama_penerima'] == 'Andi') ? 'selected' : ''; ?>>Andi</option>
                                                        <option value="Dewi" <?php echo ($row['nama_penerima'] == 'Dewi') ? 'selected' : ''; ?>>Dewi</option>
                                                        <option value="Rina" <?php echo ($row['nama_penerima'] == 'Rina') ? 'selected' : ''; ?>>Rina</option>
                                                        <option value="Joko" <?php echo ($row['nama_penerima'] == 'Joko') ? 'selected' : ''; ?>>Joko</option>
                                                    </select>
                                                </td>
                                                <td>
                                                    <button id="submit" name="keterangan" value="disetujui" class="btn btn-success btn-sm">Disetujui</button>
                                                    <button type="submit" name="keterangan" value="ditolak" class="btn btn-danger btn-sm">Ditolak</button>
                                                </td>
                                                <td>
                                                    <!-- Tambahkan tombol untuk mengarah ke laporan.php -->
                                                    <a href="laporan.php?id_pengajuan=<?php echo $row['id_pengajuan']; ?>" class="btn btn-info btn-sm">Laporan</a>
                                                </td>
                                            </form>
                                            </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </div>

    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/signature_pad@2.3.2/dist/signature_pad.min.js"></script>
    <script>
        var barCtx = document.getElementById('barChart').getContext('2d');
        var colors = ['rgba(255, 99, 132, 1)', 'rgba(255, 206, 86, 1)', 'rgba(54, 162, 235, 1)', 'rgba(75, 192, 192, 1)', 'rgba(153, 102, 255, 1)', 'rgba(255, 159, 64, 1)'];
        var barChart = new Chart(barCtx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode(array_column($kunjungan_data, 'date')); ?>,
                datasets: [{
                    label: 'Visits',
                    data: <?php echo json_encode(array_column($kunjungan_data, 'count')); ?>,
                    backgroundColor: colors,
                    borderColor: colors,
                    borderWidth: 1
                }]
            },
            options: {
                plugins: { legend: { display: false } },
                scales: { y: { beginAtZero: true } }
            }
        });

        

        document.querySelector('form').addEventListener('submit', function(e) {
            var fileInput = document.getElementById('gambar_galeri');
            var submitButton = document.querySelector('button[type="submit"]');
            
            if (submitButton.name === 'add_galeri' && fileInput.files.length === 0) {
                e.preventDefault();
                alert('Silakan pilih gambar untuk ditambahkan');
            }
        });

        function updateNamaPenerima(id) {
    var bidangPenerima = document.getElementById('bidang_penerima_' + id).value;
    var namaPenerimaSelect = document.getElementById('nama_penerima_' + id);

    // Reset pilihan nama penerima
    namaPenerimaSelect.innerHTML = '<option value="">Pilih Nama Penerima</option>';

    if (bidangPenerima) {
        // Mengambil pilihan nama penerima dari server
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "process_nama_bidang.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                var options = JSON.parse(xhr.responseText);
                options.forEach(function (name) {
                    var option = document.createElement('option');
                    option.value = name;
                    option.text = name;
                    namaPenerimaSelect.add(option);
                });
            }
        };
        xhr.send("bidang_penerima=" + encodeURIComponent(bidangPenerima));
    }
}

    </script>
</body>
</html>

<?php
$conn->close();
?>
