<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_pengaduan";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch news from the database
$sql = "SELECT * FROM news ORDER BY created_at DESC LIMIT 6";
$result = $conn->query($sql);

$news_items = [];
if ($result->num_rows > 0) {
    // Fetch all news items
    while ($row = $result->fetch_assoc()) {
        $news_items[] = $row;
    }
}

// Close connection
$conn->close();

// Return news items
return $news_items;
?>
