<?php
session_start(); 
// Pastikan user sudah login
if (!isset($_SESSION['session_username'])) {
    header("Location: index.html");
    exit();
}

// Mengatur waktu kedaluwarsa sesi (1 jam)
$news_items = include 'fetch_news.php';

// Tambahkan koneksi database dan query untuk events
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_pep";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_SESSION['session_username'];

// Query untuk semua events
$sql = "SELECT * FROM events";
$result = $conn->query($sql);

$events = [];
while ($row = $result->fetch_assoc()) {
    $events[] = [
        'title' => $row['event_name'],
        'start' => $row['event_date'] . 'T' . $row['event_time'],
        'description' => $row['description']
    ];
}

// Query untuk events hari ini
$today = date('Y-m-d');
$sql_today = "SELECT * FROM events WHERE event_date = '$today' ORDER BY event_time";
$result_today = $conn->query($sql_today);

$events_today = [];
while ($row = $result_today->fetch_assoc()) {
    $events_today[] = $row;
}

// Fungsi untuk mengubah ukuran dan memotong gambar
function resizeAndCropImage($sourcePath, $targetPath, $targetWidth, $targetHeight) {
    list($sourceWidth, $sourceHeight, $sourceType) = getimagesize($sourcePath);
    
    switch ($sourceType) {
        case IMAGETYPE_JPEG:
            $sourceImage = imagecreatefromjpeg($sourcePath);
            break;
        case IMAGETYPE_PNG:
            $sourceImage = imagecreatefrompng($sourcePath);
            break;
        case IMAGETYPE_GIF:
            $sourceImage = imagecreatefromgif($sourcePath);
            break;
        default:
            return false;
    }
    
    $targetImage = imagecreatetruecolor($targetWidth, $targetHeight);
    
    $sourceRatio = $sourceWidth / $sourceHeight;
    $targetRatio = $targetWidth / $targetHeight;
    
    if ($sourceRatio > $targetRatio) {
        $crop_width = $sourceHeight * $targetRatio;
        $crop_height = $sourceHeight;
        $crop_x = ($sourceWidth - $crop_width) / 2;
        $crop_y = 0;
    } else {
        $crop_width = $sourceWidth;
        $crop_height = $sourceWidth / $targetRatio;
        $crop_x = 0;
        $crop_y = ($sourceHeight - $crop_height) / 2;
    }
    
    imagecopyresampled($targetImage, $sourceImage, 0, 0, $crop_x, $crop_y, $targetWidth, $targetHeight, $crop_width, $crop_height);
    
    switch ($sourceType) {
        case IMAGETYPE_JPEG:
            imagejpeg($targetImage, $targetPath, 90);
            break;
        case IMAGETYPE_PNG:
            imagepng($targetImage, $targetPath, 9);
            break;
        case IMAGETYPE_GIF:
            imagegif($targetImage, $targetPath);
            break;
    }
    
    imagedestroy($sourceImage);
    imagedestroy($targetImage);
    
    return true;
}
?>

<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>PEP DJP Jatim II</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="fontawesome/all.min.css">
    <link rel="shortcut icon" href="images/fav2.ico">
    <link rel="stylesheet" href="css/style.css">
    <!-- FullCalendar CSS -->
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@5.10.1/main.min.css" rel="stylesheet" />

    <!-- FullCalendar JS -->
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.10.1/main.min.js"></script>

    <style>
        .reminder-container {
            background-color: #f8f9fa;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin: 20px 0;
            padding: 20px;
        }
        .reminder-title {
            color: #003f72;
            font-size: 1.5em;
            font-weight: bold;
            margin-bottom: 15px;
            text-align: center;
        }
        .reminder-event {
            background-color: #fff;
            border-left: 5px solid #003f72;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
            margin-bottom: 15px;
            padding: 15px;
        }
        .reminder-event-title {
            color: #003f72;
            font-size: 1.2em;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .reminder-event-time {
            color: #6c757d;
            font-size: 0.9em;
            margin-bottom: 5px;
        }
        .reminder-event-description {
            color: #495057;
            font-size: 1em;
        }

        .card-img-overlay {
            background: rgba(0,0,0,0.2);
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .card:hover .card-img-overlay {
            opacity: 1;
        }

        .card-img-overlay .btn {
            transition: all 0.3s ease;
            transform: scale(0.8);
        }

        .card:hover .card-img-overlay .btn {
            transform: scale(1);
        }

        .news-image-container {
            position: relative;
            overflow: hidden;
        }

        .news-image-container img {
            transition: filter 0.3s ease;
        }

        .news-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .news-image-container:hover .news-overlay {
            opacity: 1;
        }

        .news-image-container:hover img {
            filter: blur(3px);
        }

        .news-overlay .btn {
            transition: all 0.3s ease;
            transform: scale(0.8);
        }

        .news-image-container:hover .news-overlay .btn {
            transform: scale(1);
        }

        .card-img-top {
            width: 100%;
            height: 200px; /* Sesuaikan dengan rasio yang Anda inginkan */
            object-fit: cover;
        }

        .quick-link {
            background-color: #003f72;
            color: white;
            height: 150px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            transition: all 0.3s ease;
            border-radius: 10px;
            padding: 20px;
        }
        .quick-link:hover {
            background-color: #005a9e;
            text-decoration: none;
            color: white;
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .quick-link i {
            font-size: 40px;
            margin-bottom: 10px;
        }
        .quick-link span {
            font-size: 16px;
            font-weight: bold;
        }

        .aturan-item {
            background-color: #f8f9fa;
            border: 1px solid #e9ecef;
            border-radius: 5px;
            padding: 15px;
            display: flex;
            align-items: center;
            transition: all 0.3s ease;
            height: 80px;
            text-decoration: none;
            color: #333;
        }

        .aturan-item:hover {
            background-color: #e9ecef;
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            text-decoration: none;
            color: #333;
        }

        .aturan-item i {
            font-size: 24px;
            margin-right: 15px;
            color: #003f72;
        }

        .aturan-item span {
            font-size: 16px;
            font-weight: bold;
        }

        .bg-info {
            background-color: #17a2b8 !important;
        }

        marquee {
            font-size: 18px;
            line-height: 1.5;
        }

        .carousel-control-prev,
        .carousel-control-next {
            width: 5%; /* Lebar tombol */
        }

        .carousel-control-prev-icon,
        .carousel-control-next-icon {
            background-color: #003f72; /* Warna latar belakang tombol */
            border-radius: 50%; /* Membuat tombol bulat */
            padding: 10px; /* Jarak di dalam tombol */
        }

        .carousel-control-prev-icon:hover,
        .carousel-control-control-next-icon:hover {
            background-color: #003f72; /* Warna latar saat hover */
        }

        .carousel-control-prev {
            left: -60px; /* Jarak tombol prev dari kiri */
        }

        .carousel-control-next {
            right: -60px; /* Jarak tombol next dari kanan */
        }

        .card {
            border: none; /* Menghilangkan border pada kartu */
        }

        .card-img-top {
            height: 200px; /* Tinggi tetap untuk gambar */
            object-fit: cover; /* Memastikan gambar tetap proporsional */
        }

        .nav-item .fa-user-circle {
            color: white;
            transition: color 0.3s ease;
        }

        .nav-item:hover .fa-user-circle {
            color: #f8f9fa;
        }

        #bannerCarousel {
            max-height: 33vh; /* Set maximum height to 1/3 of viewport height */
            overflow: hidden;
        }
        #bannerCarousel .carousel-item {
            height: 33vh;
        }
        #bannerCarousel .carousel-item img {
            object-fit: cover;
            object-position: center;
            height: 100%;
            width: 100%;
        }
        .carousel-caption {
            background-color: rgba(0, 0, 0, 0.5);
            padding: 10px;
            border-radius: 5px;
        }
    </style>
</head>


<body id="top">

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #003f72;" fixed-top>
    <div class="container">
        <a class="navbar-brand" href="#top">
            <img src="images/Group 1.png" class="logo" alt="Logo Kementerian Keuangan" loading="lazy" style="width: 250px; height: auto;">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item"><a class="nav-link" href="#top">Beranda</a></li>
                <li class="nav-item"><a class="nav-link" href="#berita">Berita</a></li>
                <li class="nav-item"><a class="nav-link" href="#infoUMKM">Pustaka</a></li>
                <li class="nav-item"><a class="nav-link" href="#galeri">Galeri</a></li>
                <li class="nav-item"><a class="nav-link" href="#kontak">Kalender</a></li>
                <li class="nav-item"><a class="nav-link" href="pengajuancuti.php">Cuti</a></li>
                <li class="nav-item">
                    <a class="nav-link" href="profile.php" title="Profile User">
                        <i class="fas fa-user-circle fa-lg"></i>
                    </a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="jumbotron" style="padding-top: 5px; padding-bottom: 50px;">
    <div class="container text-center">
        <h1 style="font-size: 2.0em;">BIDANG PENDAFTARAN, EKSTENTIFIKASI, DAN PENILAIAN<br>KANTOR WILAYAH DIREKTORAT JENDERAL PAJAK<br>JAWA TIMUR II</h1>
        <a href="detail.html" class="btn btn-sm btn-info">Selengkapnya..</a>
    </div>
</div>

<!-- Banner Carousel -->
<div class="container-fluid px-0">
    <div id="bannerCarousel" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
            <!-- First Slide -->
            <div class="carousel-item active">
                <img src="images/banner1.jpg" class="d-block w-100" alt="Banner 1">
                <div class="carousel-caption d-none d-md-block">
                    <h5>Kunjungi Kemenkeu Learning Center Sekarang!</h5>
                </div>
            </div>
            <!-- Second Slide -->
            <div class="carousel-item">
                <img src="images/banner2.png" class="d-block w-100" alt="Banner 2">
                <div class="carousel-caption d-none d-md-block">
                    <h5>Belajar Lebih Mudah Dengan Kemenkeu Learning Center</h5>
                </div>
            </div>
            <!-- Add more slides if needed -->
        </div>
        <a class="carousel-control-prev" href="#bannerCarousel" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#bannerCarousel" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
</div>

<!-- Reminder Section -->
<?php if (!empty($events_today)): ?>
<div class="container">
    <div class="reminder-container">
        <div class="reminder-title">Agenda Hari Ini</div>
        <?php foreach ($events_today as $event): ?>
        <div class="reminder-event">
            <div class="reminder-event-title"><?php echo htmlspecialchars($event['event_name']); ?></div>
            <div class="reminder-event-time">
                <i class="fas fa-clock"></i> <?php echo date('H:i', strtotime($event['event_time'])); ?>
            </div>
            <div class="reminder-event-description">
                <?php echo htmlspecialchars($event['description']); ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<!-- Berita Section -->
<section id="berita" class="pb-4">
    <div class="container mb-2">
        <div class="row pt-4 mb-4">
            <div class="col text-center">
                <h2>Berita</h2>
            </div>
        </div>

        <div class="row">
            <?php if (!empty($news_items)): ?>
                <?php 
                $count = 0;
                foreach ($news_items as $news): 
                    if ($count % 3 == 0 && $count != 0): ?>
                        </div><div class="row mt-4">
                    <?php endif; ?>
                    <div class="col-md-4 col-sm-6 mb-4">
                        <div class="card">
                            <div class="news-image-container">
                                <?php
                                $image_path = "uploads/" . $news['cover_image'];
                                if (!file_exists($image_path)) {
                                    $image_path = "path/to/default/image.jpg"; // Ganti dengan path ke gambar default
                                }
                                ?>
                                <img src="<?php echo $image_path; ?>" alt="Cover Image" class="card-img-top">
                                <div class="news-overlay">
                                    <a href="<?php echo $news['link']; ?>" class="btn btn-sm btn-info">Selengkapnya</a>
                                </div>
                            </div>
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $news['title']; ?></h5>
                            </div>
                        </div>
                    </div>
                <?php 
                $count++;
                if ($count >= 6) break; // Hentikan setelah 6 item
                endforeach; ?>
            <?php else: ?>
                <div class="col-12">
                    <p class="text-center">Tidak ada berita tersedia.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Dasar Aturan Section -->
<section id="dasarAturan" class="pb-4">
    <div class="container mb-2">
        <div class="row pt-4 mb-4">
            <div class="col text-center">
                <h2>Dasar Aturan</h2>
            </div>
        </div>
        <div class="row">
            <?php
            // Ambil data dari tabel dasar_aturan
            $query = "SELECT nama_aturan AS title, link FROM dasar_aturan";
            $result = $conn->query($query);
            
            // Default icon, bisa diganti atau diambil dari database jika perlu
            $default_icon = 'fas fa-book';

            if ($result->num_rows > 0) {
                $index = 0;
                while ($row = $result->fetch_assoc()) {
                    if ($index % 4 == 0 && $index != 0) {
                        echo '</div><div class="row">';
                    }
                    echo '<div class="col-md-3 col-sm-6 mb-4">';
                    echo '<a href="' . $row['link'] . '" class="aturan-item" target="_blank">';
                    echo '<i class="' . $default_icon . '"></i>';
                    echo '<span>' . $row['title'] . '</span>';
                    echo '</a>';
                    echo '</div>';
                    $index++;
                }
            } else {
                echo '<p class="text-center">Data tidak tersedia.</p>';
            }
            ?>
        </div>
    </div>
</section>

<!-- Materi per subbidang. -->
<section id="infoUMKM" class="pb-4">
    <div class="container mb-2">
        <div class="row pt-4 mb-4">
        <div class="col text-center">
                <h2>Materi Per Seksi</h2>
            </div>
        </div>

        <div class="row">
            <div class="col-md-4 col-sm-12">
                <figure>
                    <img src="images/pendaftaran.jpeg" alt="Pendaftaran" class="img-fluid">
                    <figcaption>
                        <h3>Pendaftaran</h3>
                        <a href="galeri.php" class="btn btn-sm btn-info">Lihat</a>
                    </figcaption>
                </figure>
            </div>
            <div class="col-md-4 col-sm-12">
                <figure>
                    <img src="images/ektentifikasi.jpeg" alt="Ekstentifikasi" class="img-fluid">
                    <figcaption>
                        <h3>Ekstentifikasi</h3>
                        <a href="galeri2.php" class="btn btn-sm btn-info">Lihat</a>
                    </figcaption>
                </figure>
            </div>
            <div class="col-md-4 col-sm-12">
                <figure>
                    <img src="images/penilaian.png" alt="Penilaian" class="img-fluid">
                    <figcaption>
                        <h3>Penilaian</h3>
                        <a href="galeri3.php" class="btn btn-sm btn-info">Lihat</a>
                    </figcaption>
                </figure>
            </div>
        </div>
    </div>
</section>

<!-- Quick Links Section -->
<section id="quickLinks" class="pb-4">
    <div class="container mb-2">
        <div class="row pt-4 mb-4">
            <div class="col text-center">
                <h2>Tautan Cepat</h2>
            </div>
        </div>
        <div class="row">
            <?php
           $tautan_query = "SELECT nama_tautan, link FROM tautan";
           $tautan_result = $conn->query($tautan_query);
           
           if ($tautan_result === false) {
            die("Error dalam query: " . $conn->error);
        }

           // Loop melalui data tautan dan tampilkan
           if ($tautan_result->num_rows > 0) {
               while ($row = $tautan_result->fetch_assoc()) {
                   echo '<div class="col-md-3 col-sm-6 mb-4">';
                   echo '<a href="' . $row['link'] . '" class="quick-link d-block" target="_blank">';
                   echo '<i class="fas fa-link"></i>'; // Icon yang sama untuk semua tautan
                   echo '<span>' . $row['nama_tautan'] . '</span>';
                   echo '</a>';
                   echo '</div>';
               }
           } else {
               echo '<div class="col text-center"><p>Tidak ada tautan tersedia.</p></div>';
           }
            ?>
        </div>
    </div>
</section>

<!-- Galeri Section -->
<!-- Galeri Section -->
<section id="galeri" class="pb-4">
    <div class="container mb-2">
        <div class="row pt-4 mb-4">
            <div class="col text-center">
                <h2>Galeri</h2>
            </div>
        </div>

        <!-- Carousel Galeri -->
        <div id="galeriCarousel" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                <?php
                // Buat koneksi database baru
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "db_pep";

                // Koneksi ke database
                $conn_galeri = new mysqli($servername, $username, $password, $dbname);

                // Periksa koneksi
                if ($conn_galeri->connect_error) {
                    die("Connection failed: " . $conn_galeri->connect_error);
                }

                // Ambil data dari tabel galeri
                $galeri_result = $conn_galeri->query("SELECT * FROM galeri ORDER BY id DESC");

                // Periksa apakah query berhasil
                if (!$galeri_result) {
                    echo "<script>alert('Error: " . $conn_galeri->error . "');</script>";
                } else {
                    echo "<script>console.log('Jumlah data: " . $galeri_result->num_rows . "');</script>";
                    if ($galeri_result->num_rows > 0) {
                        $isActive = true; // Untuk menandai slide aktif pertama
                        $count = 0; // Menghitung jumlah gambar
                        echo '<div class="carousel-item ' . ($isActive ? 'active' : '') . '"><div class="row">';
                        
                        while ($row = $galeri_result->fetch_assoc()) {
                            if ($count > 0 && $count % 6 == 0) {
                                // Jika sudah 6 gambar, tutup div.row dan buka item baru
                                echo '</div></div>'; // Tutup row dan item
                                echo '<div class="carousel-item"><div class="row">'; // Item baru
                            }

                            // Menampilkan gambar
                            ?>
                            <div class="col-md-4 mb-3">
                                <div class="card">
                                    <img class="card-img-top" src="uploads/<?php echo htmlspecialchars($row['gambar']); ?>" alt="<?php echo htmlspecialchars($row['judul']); ?>">
                                    <div class="card-body">
                                        <h5 class="card-title"><?php echo htmlspecialchars($row['judul']); ?></h5>
                                    </div>
                                </div>
                            </div>
                            <?php
                            $count++;
                        }
                        echo '</div></div>'; // Tutup div.row dan item terakhir
                    } else {
                        echo "<p class='text-center'>Tidak ada data galeri.</p>";
                    }
                }

                // Tutup koneksi
                $conn_galeri->close();
                ?>
            </div>
            <a class="carousel-control-prev" href="#galeriCarousel" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#galeriCarousel" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
    </div>
</section>



<!-- Running Text -->
<div class="container-fluid bg-info py-2 mb-4">
    <marquee behavior="scroll" direction="left" scrollamount="5">
        <span class="text-white font-weight-bold">Selamat Bekerja dan Sehat Selalu!</span>
    </marquee>
</div>

<!-- Kalender Section -->
<section id="kalender" class="pb-4">
    <div class="container">
        <div class="row pt-4 mb-4">
            <div class="col text-center">
                <h2>Kalender</h2>
            </div>
        </div>
        <div class="row justify-content-center align-items-center text-center">
            <div class="col-md-6">
                <div id="calendar"></div> <!-- Placeholder for the calendar -->
            </div>
        </div>
    </div>
</section>

<!-- Kontak Section -->
<section id="kontak" class="text-white pb-4">
    <div class="container">
        <div class="row pt-4 mb-4">
            <div class="col text-center">
                <h2>Kontak</h2>
            </div>
        </div>
        <div class="row justify-content-center">
            <div id="sosmed" class="col-md-3 mb-4 text-center">
                <h3>Media Sosial</h3>
                <div class="row mb-2">
                    <div class="col">
                        <a href=""><i class="fab fa-fw fa-facebook fa-2x mr-2"></i></a>
                        <a href=""><i class="fab fa-fw fa-instagram fa-2x mr-2"></i></a>
                        <a href=""><i class="fab fa-fw fa-twitter fa-2x mr-2"></i></a>
                        <a href=""><i class="fab fa-fw fa-youtube fa-2x mr-2"></i></a>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <a href=""><i class="fab fa-fw fa-whatsapp fa-2x mr-2"></i></a>
                        <a href=""><i class="fab fa-fw fa-line fa-2x mr-2"></i></a>
                        <a href=""><i class="fab fa-fw fa-telegram fa-2x mr-2"></i></a>
                        <a href=""><i class="fas fa-fw fa-envelope fa-2x mr-2"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Footer -->
<footer class="text-center text-light bg-dark p-2">
    <p class="mt-3">Website by Amelia</p>
</footer>

<a id="backtotop" href="#top"><img src="images/angle-up.svg" alt=""></a>

<script src="js/jquery-3.5.1.slim.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="fontawesome/all.min.js"></script>
<script src="js/main.js"></script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        var calendarEl = document.getElementById('calendar');

        var calendar = new FullCalendar.Calendar(calendarEl, {
            initialView: 'dayGridMonth',
            locale: 'id',
            headerToolbar: {
                left: 'prev,next today',
                center: 'title',
                right: 'dayGridMonth'
            },
            events: <?php echo json_encode($events); ?>,
            eventClick: function(info) {
                alert('Event: ' + info.event.title + '\nDescription: ' + info.event.extendedProps.description);
            },
            navLinks: true,
            editable: false,
            dayMaxEvents: true
        });

        calendar.render();
    });
</script>

<style>
.galeri-container {
    position: relative;
    padding: 0 50px;
    margin-bottom: 30px;
}
.galeri-slider {
    overflow: hidden;
    margin-bottom: 20px;
}
.galeri-item {
    position: relative;
    overflow: hidden;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    transition: transform 0.3s ease;
    margin: 0 10px;
}
.galeri-item:hover {
    transform: scale(1.05);
}
.galeri-item img {
    width: 100%;
    height: 200px;
    object-fit: cover;
}
.galeri-caption {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    background-color: rgba(0,0,0,0.7);
    color: white;
    padding: 10px;
    text-align: center;
    transition: opacity 0.3s ease;
    opacity: 0;
}
.galeri-item:hover .galeri-caption {
    opacity: 1;
}
.galeri-prev,
.galeri-next {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    background-color: rgba(0, 0, 0, 0.7);
    color: white;
    border: none;
    padding: 15px 20px;
    font-size: 24px;
    cursor: pointer;
    z-index: 1;
    border-radius: 50%;
    transition: background-color 0.3s ease;
}
.galeri-prev {
    left: 0;
}
.galeri-next {
    right: 0;
}
.galeri-prev:hover,
.galeri-next:hover {
    background-color: rgba(0, 0, 0, 0.9);
}
</style>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css">

<script>
$(document).ready(function(){
    $('.galeri-slider-top, .galeri-slider-bottom').slick({
        slidesToShow: 3,
        slidesToScroll: 1,
        arrows: false,
        infinite: true,
        responsive: [
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 2
                }
            },
            {
                breakpoint: 576,
                settings: {
                    slidesToShow: 1
                }
            }
        ]
    });

    $('.galeri-prev').click(function(){
        $('.galeri-slider-top').slick('slickPrev');
        $('.galeri-slider-bottom').slick('slickPrev');
    });

    $('.galeri-next').click(function(){
        $('.galeri-slider-top').slick('slickNext');
        $('.galeri-slider-bottom').slick('slickNext');
    });

    // Sinkronisasi slider
    $('.galeri-slider-top').on('afterChange', function(event, slick, currentSlide){
        $('.galeri-slider-bottom').slick('slickGoTo', currentSlide);
    });

    $('.galeri-slider-bottom').on('afterChange', function(event, slick, currentSlide){
        $('.galeri-slider-top').slick('slickGoTo', currentSlide);
    });
});
</script>

</body>
</html>