# FP_DWO_KELOMPOK_5
Final Project Pengembangan Data Warehouse dan Dashboard WHsakila2021<br/>
Dibuat oleh Kelompok 5 <br/>
Program Studi Sistem Informasi <br/>
Fakultas Ilmu Komputer <br/>
UPN "Veteran" Jawa Timur<br/>
Nama Ketua :<br/>
Ahmad Nashirul Haq (18082010028)<br/>
Nama Anggota :<br/>
Nur Hasan Assobarry (18082010007)<br/>
Khusnia Nur Rachmah (18082010008)<br/>
<br/>
Langkah-langkah yang dibutuhkan untuk menjalankan app dengan baik :
1. Install database server: MySql (disini kami menggunakan Xampp versi terbaru).
2. Install software mysql management: phpMyAdmin dari Xampp (ATAU YG LAIN).
3. Extract FP_DWO_KELOMPOK_5.zip pada folder htdocs XAMPP (xampp/htdocs).
4. Jalankan Xampp control panel.
5. Start apache dan mysql server.
6. Buka phpMyAdmin (localhost/phpmyadmin).
7. Buat database dengan nama whsakila2021.
8. Import file whsakila2021.sql ke dalam database whsakila2021.
9. Download dan Extract mondrian_18082010028.zip dari link https://bit.ly/mondrianwhsakilaanashaq ke dalam server Tomcat bawaan dari XAMPP (xampp/tomcat/webapps).
10. Jalankan aplikasi dengan mengakses http://localhost/FP_DataWarehouseSakila2021_18082010028
