/*
 * author Saquib Shaikh
 * created on 22-10-2024-15h-05m
 * github: https://github.com/saquibshaikh14
 * copyright 2024
*/

<?php
session_start();
session_destroy();
header("Location: index.html");
?>
