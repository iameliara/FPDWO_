<?php
session_start();

// Pastikan user sudah login
if (!isset($_SESSION['session_username'])) {
    header("Location: index.html");
    exit();
}

// Koneksi ke database
$servername = "localhost";
$db_username = "root"; // username untuk koneksi database
$password = "";
$dbname = "db_pep";

$conn = new mysqli($servername, $db_username, $password, $dbname);

// Cek koneksi ke database
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ambil username dari session
$username = $_SESSION['session_username'];

// Debug: Tampilkan username dari session

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pengajuan Cuti</title>
    <!-- Import Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <!-- Custom CSS -->
    <style>
        /* Global Styles */
        body {
            font-family: 'Poppins', sans-serif; /* Menggunakan font modern */
            background-color: #eef2f7; /* Background global yang lebih lembut */
            color: #333;
            margin: 0;
            padding: 0;
        }

        /* Section Pengajuan Cuti */
        #pengajuan-cuti {
            background-color: #fff; /* Latar belakang putih untuk kontras */
            border-radius: 10px; /* Membuat sudut form lebih halus */
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1); /* Bayangan halus di sekitar section */
            padding: 30px; /* Padding lebih besar agar tampak luas */
            margin: 40px auto; /* Tengah halaman */
            max-width: 600px; /* Lebar maksimal form */
        }

        /* Form Styles */
        form {
            background-color: #fff;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05); /* Bayangan halus pada form */
        }

        /* Table Styles */
        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }

        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        /* Label Styles */
        form label {
            color: #555;
            font-weight: 600;
            margin-bottom: 8px;
            display: block;
        }

        /* Select & Input Styles */
        select, input[type="date"] {
            background-color: #f7f7f7;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 10px;
            font-size: 16px;
            color: #333;
            width: 100%;
            transition: all 0.3s ease;
        }

        select:focus, input[type="date"]:focus {
            outline: none;
            border-color: #007bff; /* Warna biru saat fokus */
            box-shadow: 0 0 6px rgba(0, 123, 255, 0.2); /* Efek bayangan saat fokus */
        }

        /* Button Styles */
        .btn-primary {
            background-color: #007bff; /* Warna biru modern */
            border-color: #007bff;
            color: #fff;
            font-size: 16px;
            padding: 12px;
            border-radius: 8px;
            transition: all 0.3s ease;
            box-shadow: 0 4px 10px rgba(0, 123, 255, 0.2); /* Bayangan tombol */
            width: 100%; /* Lebar penuh */
        }

        .btn-primary:hover {
            background-color: #0056b3; /* Warna saat hover */
            border-color: #0056b3;
            box-shadow: 0 6px 15px rgba(0, 86, 179, 0.3); /* Bayangan lebih besar saat hover */
        }

        /* Responsiveness */
        @media (max-width: 768px) {
            #pengajuan-cuti {
                padding: 20px;
            }

            .btn-primary {
                font-size: 14px;
                padding: 10px;
            }
        }
    </style>
</head>
<body>

<!-- Pengajuan Cuti Section -->
<section id="pengajuan-cuti" class="pb-5">
    <div class="container">
        <div class="row pt-5 mb-4">
            <div class="col text-center">
                <h2 class="font-weight-bold" style="color: #333;">Pengajuan Cuti</h2>
                <p class="text-muted">Silakan isi form di bawah untuk pengajuan cuti</p>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-md-12">
                <form action="process_cuti.php" method="post">
                    <div class="form-group mb-4">
                        <label for="perihal" class="font-weight-bold">Perihal:</label>
                        <select class="form-control" id="perihal" name="perihal" required>
                            <option value="" disabled selected>Pilih Perihal</option>
                            <option value="cuti tahunan">Cuti Tahunan</option>
                            <option value="cuti sakit">Cuti Sakit</option>
                            <option value="cuti alasan penting">Cuti Alasan Penting</option>
                        </select>
                    </div>
                    <div class="form-group mb-4">
                        <label for="tanggal_mulai_cuti" class="font-weight-bold">Tanggal Mulai Cuti:</label>
                        <input type="date" class="form-control" id="tanggal_mulai_cuti" name="tanggal_mulai_cuti" required>
                    </div>
                    <div class="form-group mb-4">
                        <label for="tanggal_akhir_cuti" class="font-weight-bold">Tanggal Akhir Cuti:</label>
                        <input type="date" class="form-control" id="tanggal_akhir_cuti" name="tanggal_akhir_cuti" required>
                    </div>
                    <div class="form-group mb-4">
                        <label for="lama_cuti" class="font-weight-bold">Lama Cuti (Masukan Jumlah Hari):</label>
                        <input type="number" class="form-control" id="lama_cuti" name="lama_cuti" min="1" required>
                    </div>
                    <div class="text-center">
                        <button type="submit" class="btn btn-primary btn-lg">Ajukan Cuti</button>
                    </div>
                </form>
            </div>
        </div>
        <?php
// Cek apakah session sudah dimulai
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Pastikan username di session ada
if (isset($_SESSION['session_username'])) {
    $username = $_SESSION['session_username'];
} else {
    // Jika session tidak ada, redirect atau tampilkan pesan error
    die("Anda belum login.");
}
?>

<!-- Tampilkan Data Pengajuan Cuti --> 
<div class="row justify-content-center">
    <div class="col-md-12">
        <h3 class="mt-4">Data Pengajuan Cuti</h3>
        <table>
            <thead>
                <tr>
                    <th>Perihal</th>
                    <th>Tanggal Mulai Cuti</th>
                    <th>Tanggal Akhir Cuti</th>
                    <th>Lama Cuti</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Ambil data dari database berdasarkan username
                $stmt = $conn->prepare("SELECT * FROM pengajuan_cuti WHERE username = ? ORDER BY tanggal_pengajuan DESC");
                $stmt->bind_param("s", $username);
                $stmt->execute();
                $result = $stmt->get_result();

                // Cek apakah ada data
                if ($result->num_rows > 0) {
                    // Tampilkan data setiap baris
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($row['perihal']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['tanggal_mulai_cuti']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['tanggal_akhir_cuti']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['lama_cuti']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['keterangan']) . "</td>"; // Ganti dengan kolom status jika ada
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='5'>Tidak ada data pengajuan cuti.</td></tr>";
                }

                $stmt->close(); // Menutup statement
                ?>
            </tbody>
        </table>
    </div>
</div>
</section>
<script>
$(document).ready(function() {
    $('#cutiForm').on('submit', function(e) {
        e.preventDefault(); // Mencegah form dari pengiriman default

        $.ajax({
            type: 'POST',
            url: 'process_cuti.php', // Ganti dengan file pemrosesan Anda
            data: $(this).serialize(),
            success: function(response) {
                if (response === "success") {
                    alert('Cuti berhasil diajukan!');
                    location.reload(); // Refresh halaman untuk memperbarui tabel
                } else {
                    alert('Terjadi kesalahan: ' + response);
                }
            },
            error: function() {
                alert('Terjadi kesalahan saat mengajukan cuti.');
            }
        });
    });
});
</script>

<?php
$conn->close(); // Menutup koneksi
?>


</body>
</html>
