<?php
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
ini_set('display_errors', '0');

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_pengaduan";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle Pengajuan Cuti
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id']; // Ambil ID dari form
    $bidang_penerima = $_POST['bidang_penerima'];
    $nama_penerima = $_POST['nama_penerima'];
    $ttd = $_POST['ttd'];
    $foto_tanda_terima = $_POST['foto_tanda_terima'];
    $keterangan = $_POST['keterangan'];
    $status = $_POST['status']; // Ambil nilai status dari tombol yang ditekan

    // Query untuk memperbarui data ke tabel cuti
    $sql = "UPDATE pengajuan_cuti SET 
            bidang_penerima='$bidang_penerima', 
            nama_penerima='$nama_penerima', 
            ttd='$ttd', 
            foto_tanda_terima='$foto_tanda_terima', 
            keterangan='$keterangan' 
            WHERE id=$id"; // Menggunakan ID untuk memperbarui data

    if ($conn->query($sql) === TRUE) {
        if ($status === 'disetujui') {
            // Logika untuk menyetujui cuti
            echo "<script>alert('Cuti Disetujui!'); window.location.href='admin_dashboard.php';</script>"; // Menampilkan pop-up sukses
        } elseif ($status === 'ditolak') {
            // Logika untuk menolak cuti
            echo "<script>alert('Cuti Ditolak.'); window.location.href='admin_dashboard.php';</script>"; // Menampilkan pop-up kesalahan
        }
    } else {
        echo "<script>alert('Error: " . $conn->error . "'); window.location.href='admin_dashboard.php';</script>"; // Menampilkan pesan kesalahan
    }
}
?>
