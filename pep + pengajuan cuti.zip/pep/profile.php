<?php
session_start(); // Memulai sesi

// Mengatur waktu kedaluwarsa sesi (1 jam

// Koneksi ke database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_pengaduan";

$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ambil data pengguna berdasarkan username
$_SESSION['session_username'] = $username;
$sql = "SELECT * FROM user WHERE username='$username'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $nama = htmlspecialchars($row['nama']); // Ambil nama
    $nomor = htmlspecialchars($row['nomor']); // Ambil nomor
} else {
    echo "User not found.";
    exit();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Pengguna</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h2 class="mt-5">Profil Pengguna</h2>
        <div class="card mt-3">
            <div class="card-body">
                <h5 class="card-title">Nama: <?php echo $nama; ?></h5>
                <p class="card-text">Nomor: <?php echo $nomor; ?></p>
                <a href="logout.php" class="btn btn-danger">Logout</a>
            </div>
        </div>
    </div>
</body>
</html>