<?php
if (isset($_POST['bidang_penerima'])) {
    $bidang_penerima = $_POST['bidang_penerima'];
    $nama_penerima_options = [];

    // Menentukan pilihan nama penerima berdasarkan bidang penerima
    switch ($bidang_penerima) {
        case 'Bidang Sekretaris Kanwil':
            $nama_penerima_options = [
                'Sari',
                'Budi'
            ];
            break;
        case 'Bidang PEP':
            $nama_penerima_options = [
                'Andi',
                'Dewi'
            ];
            break;
        case 'Bidang Umum':
            $nama_penerima_options = [
                'Rina',
                'Joko'
            ];
            break;
        default:
            $nama_penerima_options = [];
            break;
    }

    // Mengembalikan pilihan nama penerima dalam format JSON
    echo json_encode($nama_penerima_options);
}
?>