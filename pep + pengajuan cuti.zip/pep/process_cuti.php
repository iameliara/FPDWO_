<?php
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
ini_set('display_errors', '0');

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_pengaduan";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle Pengajuan Cuti
session_start(); // Mulai session jika belum dimulai
$id_user = $_SESSION['id_user']; // Ambil id_user dari session

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil data dari formulir
    $perihal = $_POST['perihal'];
    $tanggal_mulai_cuti = $_POST['tanggal_mulai_cuti'];
    $tanggal_akhir_cuti = $_POST['tanggal_akhir_cuti'];
    $lama_cuti = $_POST['lama_cuti'];

    // Ambil nama pengguna dari tabel user
    $sql_user = "SELECT nama FROM user WHERE id = '$id_user'";
    $result_user = $conn->query($sql_user);
    $nama = ''; // Inisialisasi variabel nama

    if ($result_user->num_rows > 0) {
        $row_user = $result_user->fetch_assoc();
        $nama = $row_user['nama']; // Ambil nama dari hasil query
    }

    // Menentukan jenis surat berdasarkan perihal
    switch ($perihal) {
        case 'cuti tahunan':
            $jenis_surat = 'SICT';
            break;
        case 'cuti sakit':
            $jenis_surat = 'SICS';
            break;
        case 'cuti alasan penting':
            $jenis_surat = 'SICAP';
            break;
        default:
            $jenis_surat = 'Unknown';
            break;
    }

    // Ambil nomor surat terakhir dari database
    $sql_last_number = "SELECT nomor_surat FROM pengajuan_cuti WHERE jenis_surat = '$jenis_surat' ORDER BY id DESC LIMIT 1";
    $result_last_number = $conn->query($sql_last_number);
    $last_number = 0;

    if ($result_last_number->num_rows > 0) {
        $row = $result_last_number->fetch_assoc();
        preg_match('/^' . preg_quote($jenis_surat, '/') . '\/(\d+)\/WPJ243\/2025$/', $row['nomor_surat'], $matches);
        if (isset($matches[1])) {
            $last_number = (int)$matches[1];
        }
    }

    $new_number = $last_number + 1;
    $nomor_surat = "$jenis_surat/$new_number/WPJ243/2025";

    // Query untuk menyimpan data ke tabel pengajuan_cuti dengan nama
    $sql = "INSERT INTO pengajuan_cuti (nama, perihal, jenis_surat, nomor_surat, tanggal_mulai_cuti, tanggal_akhir_cuti, lama_cuti) 
            VALUES ('$nama', '$perihal', '$jenis_surat', '$nomor_surat', '$tanggal_mulai_cuti', '$tanggal_akhir_cuti', '$lama_cuti')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Pengajuan cuti berhasil!'); window.location.href='pengajuancuti.php';</script>"; 
    } else {
        echo "<script>alert('Error: Kesalahan dalam pengajuan cuti.'); window.location.href='pengajuancuti.php';</script>"; 
    }
}
