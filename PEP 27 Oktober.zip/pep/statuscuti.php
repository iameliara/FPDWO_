<input type="hidden" id="id_pengajuan" name="id_pengajuan" value="12345"> <!-- Contoh nilai id_pengajuan -->

<?php
// Koneksi Database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_pep";

// Membuat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Proses POST Request
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_pengajuan = (int)$_POST['id_pengajuan'];
    $bidang_penerima = $conn->real_escape_string($_POST['bidang_penerima']);
    $nama_penerima = $conn->real_escape_string($_POST['nama_penerima']);
    $keterangan = $conn->real_escape_string($_POST['keterangan']);

    // Update database dengan data baru
    $sql = "UPDATE pengajuan_cuti SET 
            bidang_penerima='$bidang_penerima', 
            nama_penerima='$nama_penerima', 
            keterangan='$keterangan' 
            WHERE id_pengajuan=$id_pengajuan"; // Hapus koma setelah keterangan

    if ($conn->query($sql) === TRUE) {
        // Redirect to ttd.php after successful update
        header("Location: ttd.php?id_pengajuan=" . urlencode($id_pengajuan));
        exit; // Always exit after a header redirect to prevent further script execution
    } else {
        echo "Error: " . $conn->error;
    }
}

// Tutup koneksi
$conn->close();
?>
