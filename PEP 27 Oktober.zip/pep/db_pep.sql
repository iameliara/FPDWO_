-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 26, 2024 at 02:17 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_pep`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin123');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `event_name` varchar(255) NOT NULL,
  `event_date` date NOT NULL,
  `event_time` time NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `event_name`, `event_date`, `event_time`, `description`, `created_at`) VALUES
(1, 'Rapat Umum', '2024-06-20', '09:00:00', 'Rapat umum tahunan', '2024-09-30 02:22:53'),
(2, 'Workshop Pajak', '2024-06-25', '13:30:00', 'Workshop tentang peraturan pajak terbaru', '2024-09-30 02:22:53'),
(3, 'Seminar Keuangan', '2024-06-30', '10:00:00', 'Seminar tentang manajemen keuangan', '2024-09-30 02:22:53'),
(4, 'Birthday', '2024-09-30', '09:58:00', '-', '2024-09-30 02:59:04'),
(5, 'Birthday', '2024-10-03', '09:24:00', '-', '2024-10-03 02:25:03'),
(6, 'Rapat Kegiatan A', '2024-10-24', '08:45:00', '-', '2024-10-24 14:37:15'),
(7, 'Rapat Kegiatan A', '2024-10-24', '08:45:00', '-', '2024-10-24 14:38:17');

-- --------------------------------------------------------

--
-- Table structure for table `galeri`
--

CREATE TABLE `galeri` (
  `id` int(11) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `gambar` varchar(255) NOT NULL,
  `link` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `galeri`
--

INSERT INTO `galeri` (`id`, `judul`, `gambar`, `link`, `created_at`) VALUES
(4, 'Dokumentasi Event B', '66fa13a33dfa2.jpeg', 'http://localhost/phpmyadmin/index.php?route=/database/sql&db=db_pengaduan', '2024-09-30 02:57:39'),
(5, 'Dokumentasi Birthday', '66fa13b30cf5a.jpg', 'http://localhost/phpmyadmin/index.php?route=/database/sql&db=db_pengaduan', '2024-09-30 02:57:55'),
(6, 'Dokumentasi Event A', '66fa13c7183fa.jpg', 'https://www.kemenkeu.go.id/informasi-publik/publikasi/berita-utama/Pengelolaan-Penerimaan-Negara-Tahun-2025', '2024-09-30 02:58:15'),
(7, 'Dokumentasi Kegiatan A', '66fb5810becb6.jpeg', 'https://www.google.com/search?sa=X&sca_esv=2a0623079f1ec93f&sca_upv=1&rlz=1C1CHBD_idID1107ID1107&udm=2&sxsrf=ADLYWIKW5roa5Rft3nWy9YqS_LKeS-k9fQ:1727054377178&q=photo+gallery+website+template&stick=H4sIAAAAAAAAAFvEKleQkV-Sr5CemJOTWlSpUJ6aVJxZkqpQkppbkJNYkg', '2024-10-01 02:01:52'),
(8, 'Dokumentasi Kegiatan B', '66fb5e2d07269.jpg', 'https://www.google.com/search?sa=X&sca_esv=2a0623079f1ec93f&sca_upv=1&rlz=1C1CHBD_idID1107ID1107&udm=2&sxsrf=ADLYWIKW5roa5Rft3nWy9YqS_LKeS-k9fQ:1727054377178&q=photo+gallery+website+template&stick=H4sIAAAAAAAAAFvEKleQkV-Sr5CemJOTWlSpUJ6aVJxZkqpQkppbkJNYkg', '2024-10-01 02:27:57'),
(9, 'Dokumentasi Birthday', '66fb5e4a01924.jpg', 'https://www.kemenkeu.go.id/informasi-publik/publikasi/berita-utama/Pengelolaan-Penerimaan-Negara-Tahun-2025', '2024-10-01 02:28:26'),
(10, 'Dokumentasi Event A', '66fb5e573a4c4.jpg', 'https://www.google.com/search?sa=X&sca_esv=2a0623079f1ec93f&sca_upv=1&rlz=1C1CHBD_idID1107ID1107&udm=2&sxsrf=ADLYWIKW5roa5Rft3nWy9YqS_LKeS-k9fQ:1727054377178&q=photo+gallery+website+template&stick=H4sIAAAAAAAAAFvEKleQkV-Sr5CemJOTWlSpUJ6aVJxZkqpQkppbkJNYkg', '2024-10-01 02:28:39'),
(11, 'Dokumentasi September', '66fcec81eaaac.jpeg', 'http://localhost/phpmyadmin/index.php?route=/database/sql&db=db_pengaduan', '2024-10-02 06:47:29');

-- --------------------------------------------------------

--
-- Table structure for table `kunjungan`
--

CREATE TABLE `kunjungan` (
  `id` int(11) NOT NULL,
  `timestamp` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kunjungan`
--

INSERT INTO `kunjungan` (`id`, `timestamp`) VALUES
(1, '2024-09-30 09:48:28'),
(2, '2024-09-30 09:48:53'),
(3, '2024-09-30 09:49:00'),
(4, '2024-09-30 09:49:06'),
(5, '2024-09-30 09:49:10'),
(6, '2024-09-30 09:49:14'),
(7, '2024-09-30 09:49:19'),
(8, '2024-09-30 09:49:23'),
(9, '2024-09-30 09:49:25'),
(10, '2024-09-30 09:49:28'),
(11, '2024-09-30 09:52:34'),
(12, '2024-09-30 09:53:53'),
(13, '2024-09-30 09:54:43'),
(14, '2024-09-30 09:55:29'),
(15, '2024-09-30 09:55:48'),
(16, '2024-09-30 09:56:06'),
(17, '2024-09-30 09:56:27'),
(18, '2024-09-30 09:57:17'),
(19, '2024-09-30 09:57:39'),
(20, '2024-09-30 09:57:55'),
(21, '2024-09-30 09:58:15'),
(22, '2024-09-30 09:59:04'),
(23, '2024-09-30 10:56:28'),
(24, '2024-10-01 09:01:26'),
(25, '2024-10-01 09:01:52'),
(26, '2024-10-01 09:11:37'),
(27, '2024-10-01 09:13:26'),
(28, '2024-10-01 09:13:44'),
(29, '2024-10-01 09:13:45'),
(30, '2024-10-01 09:13:48'),
(31, '2024-10-01 09:20:02'),
(32, '2024-10-01 09:21:09'),
(33, '2024-10-01 09:26:55'),
(34, '2024-10-01 09:27:57'),
(35, '2024-10-01 09:28:26'),
(36, '2024-10-01 09:28:39'),
(37, '2024-10-02 13:35:25'),
(38, '2024-10-02 13:37:44'),
(39, '2024-10-02 13:38:19'),
(40, '2024-10-02 13:39:14'),
(41, '2024-10-02 13:39:30'),
(42, '2024-10-02 13:43:45'),
(43, '2024-10-02 13:47:29'),
(44, '2024-10-02 13:47:57'),
(45, '2024-10-02 14:36:18'),
(46, '2024-10-02 14:38:27'),
(47, '2024-10-02 14:38:51'),
(48, '2024-10-03 09:24:42'),
(49, '2024-10-03 09:25:03'),
(50, '2024-10-03 09:25:20'),
(51, '2024-10-03 21:27:01'),
(52, '2024-10-03 21:29:17'),
(53, '2024-10-15 11:57:26'),
(54, '2024-10-15 12:02:11'),
(55, '2024-10-15 12:05:00'),
(56, '2024-10-15 12:05:28'),
(57, '2024-10-15 12:09:46'),
(58, '2024-10-15 12:09:50'),
(59, '2024-10-15 12:09:54'),
(60, '2024-10-15 12:10:03'),
(61, '2024-10-15 12:10:16'),
(62, '2024-10-15 12:12:48'),
(63, '2024-10-15 12:12:51'),
(64, '2024-10-15 12:13:12'),
(65, '2024-10-15 12:15:53'),
(66, '2024-10-15 12:16:29'),
(67, '2024-10-15 12:17:25'),
(68, '2024-10-15 12:17:42'),
(69, '2024-10-15 12:21:27'),
(70, '2024-10-15 12:21:45'),
(71, '2024-10-15 12:36:56'),
(72, '2024-10-15 12:41:53'),
(73, '2024-10-15 12:42:15'),
(74, '2024-10-15 12:45:40'),
(75, '2024-10-15 12:46:02'),
(76, '2024-10-15 12:46:39'),
(77, '2024-10-15 12:46:56'),
(78, '2024-10-15 12:49:39'),
(79, '2024-10-15 12:49:55'),
(80, '2024-10-15 12:51:19'),
(81, '2024-10-15 12:51:54'),
(82, '2024-10-15 12:52:31'),
(83, '2024-10-15 12:55:47'),
(84, '2024-10-15 13:07:00'),
(85, '2024-10-15 13:07:30'),
(86, '2024-10-15 13:09:53'),
(87, '2024-10-15 13:22:04'),
(88, '2024-10-15 13:24:08'),
(89, '2024-10-15 13:29:35'),
(90, '2024-10-15 13:34:13'),
(91, '2024-10-15 13:39:08'),
(92, '2024-10-15 13:44:26'),
(93, '2024-10-15 17:35:46'),
(94, '2024-10-15 17:45:43'),
(95, '2024-10-15 17:46:47'),
(96, '2024-10-15 17:49:14'),
(97, '2024-10-15 17:53:05'),
(98, '2024-10-15 17:55:31'),
(99, '2024-10-15 17:57:25'),
(100, '2024-10-15 17:58:57'),
(101, '2024-10-15 18:03:10'),
(102, '2024-10-15 18:03:58'),
(103, '2024-10-15 18:10:22'),
(104, '2024-10-16 13:14:10'),
(105, '2024-10-16 13:25:00'),
(106, '2024-10-16 13:31:08'),
(107, '2024-10-16 13:32:35'),
(108, '2024-10-16 13:32:55'),
(109, '2024-10-16 13:35:11'),
(110, '2024-10-16 13:40:29'),
(111, '2024-10-16 13:42:46'),
(112, '2024-10-16 13:42:48'),
(113, '2024-10-16 13:44:36'),
(114, '2024-10-16 13:46:18'),
(115, '2024-10-16 13:47:59'),
(116, '2024-10-16 13:51:44'),
(117, '2024-10-16 13:51:53'),
(118, '2024-10-16 13:52:57'),
(119, '2024-10-16 13:53:18'),
(120, '2024-10-16 13:54:45'),
(121, '2024-10-16 13:54:58'),
(122, '2024-10-16 13:58:07'),
(123, '2024-10-16 13:59:47'),
(124, '2024-10-16 14:01:24'),
(125, '2024-10-16 14:04:09'),
(126, '2024-10-16 14:07:03'),
(127, '2024-10-16 14:08:52'),
(128, '2024-10-16 14:09:14'),
(129, '2024-10-16 14:15:28'),
(130, '2024-10-16 14:15:34'),
(131, '2024-10-16 14:17:38'),
(132, '2024-10-16 14:18:31'),
(133, '2024-10-16 14:22:30'),
(134, '2024-10-16 14:23:05'),
(135, '2024-10-16 14:24:09'),
(136, '2024-10-16 14:26:41'),
(137, '2024-10-16 14:27:17'),
(138, '2024-10-16 14:28:10'),
(139, '2024-10-16 14:34:00'),
(140, '2024-10-16 14:34:29'),
(141, '2024-10-16 14:40:55'),
(142, '2024-10-16 14:41:11'),
(143, '2024-10-16 14:43:44'),
(144, '2024-10-16 15:35:35'),
(145, '2024-10-16 15:38:41'),
(146, '2024-10-16 15:38:42'),
(147, '2024-10-16 15:38:43'),
(148, '2024-10-18 08:08:40'),
(149, '2024-10-18 08:12:33'),
(150, '2024-10-18 08:13:57'),
(151, '2024-10-18 08:14:13'),
(152, '2024-10-18 08:14:25'),
(153, '2024-10-18 08:14:43'),
(154, '2024-10-18 08:16:49'),
(155, '2024-10-18 08:18:00'),
(156, '2024-10-18 08:18:22'),
(157, '2024-10-18 08:24:50'),
(158, '2024-10-18 08:26:57'),
(159, '2024-10-18 08:28:23'),
(160, '2024-10-18 08:29:23'),
(161, '2024-10-18 08:29:46'),
(162, '2024-10-18 08:30:07'),
(163, '2024-10-18 08:33:05'),
(164, '2024-10-18 08:34:19'),
(165, '2024-10-18 08:36:18'),
(166, '2024-10-18 08:36:37'),
(167, '2024-10-18 08:39:56'),
(168, '2024-10-18 08:40:46'),
(169, '2024-10-18 08:41:49'),
(170, '2024-10-18 08:44:33'),
(171, '2024-10-18 08:44:56'),
(172, '2024-10-18 08:50:54'),
(173, '2024-10-18 08:51:04'),
(174, '2024-10-18 08:51:41'),
(175, '2024-10-18 08:52:21'),
(176, '2024-10-18 08:53:08'),
(177, '2024-10-18 09:02:54'),
(178, '2024-10-18 09:04:51'),
(179, '2024-10-18 09:05:40'),
(180, '2024-10-18 09:09:36'),
(181, '2024-10-18 09:16:01'),
(182, '2024-10-18 09:24:49'),
(183, '2024-10-18 10:23:00'),
(184, '2024-10-18 10:28:09'),
(185, '2024-10-18 10:38:14'),
(186, '2024-10-18 10:38:57'),
(187, '2024-10-18 11:26:37'),
(188, '2024-10-18 11:28:23'),
(189, '2024-10-18 11:29:36'),
(190, '2024-10-18 11:29:43'),
(191, '2024-10-18 11:32:22'),
(192, '2024-10-18 11:32:25'),
(193, '2024-10-18 11:32:46'),
(194, '2024-10-18 11:39:30'),
(195, '2024-10-21 08:39:13'),
(196, '2024-10-21 08:57:55'),
(197, '2024-10-21 09:01:18'),
(198, '2024-10-21 09:10:22'),
(199, '2024-10-21 09:16:23'),
(200, '2024-10-21 09:17:58'),
(201, '2024-10-21 09:25:55'),
(202, '2024-10-21 10:05:03'),
(203, '2024-10-21 10:14:57'),
(204, '2024-10-21 10:16:00'),
(205, '2024-10-21 12:24:28'),
(206, '2024-10-21 12:27:25'),
(207, '2024-10-21 12:28:53'),
(208, '2024-10-21 20:19:13'),
(209, '2024-10-21 20:36:00'),
(210, '2024-10-21 20:38:20'),
(211, '2024-10-21 20:47:37'),
(212, '2024-10-21 22:48:41'),
(213, '2024-10-21 22:51:07'),
(214, '2024-10-21 22:51:59'),
(215, '2024-10-21 22:55:39'),
(216, '2024-10-21 22:56:03'),
(217, '2024-10-21 22:58:28'),
(218, '2024-10-21 23:06:03'),
(219, '2024-10-21 23:10:00'),
(220, '2024-10-21 23:12:13'),
(221, '2024-10-21 23:15:38'),
(222, '2024-10-22 10:08:45'),
(223, '2024-10-22 11:54:18'),
(224, '2024-10-22 12:21:28'),
(225, '2024-10-22 13:36:02'),
(226, '2024-10-22 13:42:43'),
(227, '2024-10-22 13:43:31'),
(228, '2024-10-22 13:45:54'),
(229, '2024-10-22 13:48:08'),
(230, '2024-10-22 13:51:59'),
(231, '2024-10-22 13:55:37'),
(232, '2024-10-22 13:55:49'),
(233, '2024-10-22 13:59:09'),
(234, '2024-10-22 13:59:54'),
(235, '2024-10-22 14:02:32'),
(236, '2024-10-22 14:04:49'),
(237, '2024-10-22 14:04:58'),
(238, '2024-10-22 14:06:22'),
(239, '2024-10-22 14:06:49'),
(240, '2024-10-22 14:08:09'),
(241, '2024-10-22 14:08:37'),
(242, '2024-10-22 14:08:42'),
(243, '2024-10-22 14:16:50'),
(244, '2024-10-22 14:22:38'),
(245, '2024-10-22 14:25:13'),
(246, '2024-10-22 14:25:33'),
(247, '2024-10-22 14:26:57'),
(248, '2024-10-22 14:30:49'),
(249, '2024-10-22 14:31:42'),
(250, '2024-10-22 14:34:35'),
(251, '2024-10-22 14:34:58'),
(252, '2024-10-22 14:36:53'),
(253, '2024-10-22 14:55:48'),
(254, '2024-10-22 14:59:46'),
(255, '2024-10-22 15:00:06'),
(256, '2024-10-22 15:00:28'),
(257, '2024-10-22 15:00:40'),
(258, '2024-10-22 15:06:55'),
(259, '2024-10-22 15:07:18'),
(260, '2024-10-22 21:34:15'),
(261, '2024-10-22 21:36:07'),
(262, '2024-10-22 21:41:23'),
(263, '2024-10-23 08:55:40'),
(264, '2024-10-23 08:55:45'),
(265, '2024-10-23 08:56:30'),
(266, '2024-10-23 08:57:09'),
(267, '2024-10-23 08:57:57'),
(268, '2024-10-23 08:58:00'),
(269, '2024-10-23 11:08:19'),
(270, '2024-10-23 11:29:10'),
(271, '2024-10-23 11:35:58'),
(272, '2024-10-23 11:37:02'),
(273, '2024-10-23 11:37:46'),
(274, '2024-10-23 11:38:37'),
(275, '2024-10-23 11:41:17'),
(276, '2024-10-23 11:47:29'),
(277, '2024-10-23 12:12:35'),
(278, '2024-10-23 12:13:12'),
(279, '2024-10-23 14:29:06'),
(280, '2024-10-23 14:34:42'),
(281, '2024-10-23 14:35:55'),
(282, '2024-10-23 14:41:46'),
(283, '2024-10-23 14:45:35'),
(284, '2024-10-23 14:46:04'),
(285, '2024-10-23 14:52:10'),
(286, '2024-10-23 14:52:26'),
(287, '2024-10-23 15:12:54'),
(288, '2024-10-23 15:13:15'),
(289, '2024-10-23 15:13:53'),
(290, '2024-10-23 15:15:48'),
(291, '2024-10-23 15:23:05'),
(292, '2024-10-23 15:23:55'),
(293, '2024-10-23 15:27:54'),
(294, '2024-10-23 15:29:44'),
(295, '2024-10-23 15:31:16'),
(296, '2024-10-23 15:31:57'),
(297, '2024-10-23 15:32:46'),
(298, '2024-10-23 15:38:28'),
(299, '2024-10-23 15:38:47'),
(300, '2024-10-23 15:40:03'),
(301, '2024-10-23 15:48:44'),
(302, '2024-10-24 08:02:09'),
(303, '2024-10-24 08:08:09'),
(304, '2024-10-24 08:12:08'),
(305, '2024-10-24 08:12:26'),
(306, '2024-10-24 08:14:51'),
(307, '2024-10-24 08:18:12'),
(308, '2024-10-24 08:18:59'),
(309, '2024-10-24 08:20:39'),
(310, '2024-10-24 08:27:57'),
(311, '2024-10-24 08:28:09'),
(312, '2024-10-24 08:29:25'),
(313, '2024-10-24 08:38:41'),
(314, '2024-10-24 08:41:26'),
(315, '2024-10-24 08:57:13'),
(316, '2024-10-24 09:04:25'),
(317, '2024-10-24 09:04:43'),
(318, '2024-10-24 09:05:09'),
(319, '2024-10-24 09:05:24'),
(320, '2024-10-24 09:05:45'),
(321, '2024-10-24 09:08:45'),
(322, '2024-10-24 09:10:45'),
(323, '2024-10-24 09:11:37'),
(324, '2024-10-24 09:14:15'),
(325, '2024-10-24 09:15:13'),
(326, '2024-10-24 09:15:58'),
(327, '2024-10-24 09:23:24'),
(328, '2024-10-24 09:26:12'),
(329, '2024-10-24 09:26:31'),
(330, '2024-10-24 09:29:59'),
(331, '2024-10-24 09:32:34'),
(332, '2024-10-24 09:33:12'),
(333, '2024-10-24 09:46:16'),
(334, '2024-10-24 09:48:27'),
(335, '2024-10-24 09:49:18'),
(336, '2024-10-24 09:50:46'),
(337, '2024-10-24 09:53:43'),
(338, '2024-10-24 09:55:26'),
(339, '2024-10-24 10:00:47'),
(340, '2024-10-24 10:01:11'),
(341, '2024-10-24 10:03:34'),
(342, '2024-10-24 10:06:35'),
(343, '2024-10-24 10:10:14'),
(344, '2024-10-24 10:12:27'),
(345, '2024-10-24 10:15:28'),
(346, '2024-10-24 10:17:42'),
(347, '2024-10-24 10:17:56'),
(348, '2024-10-24 10:21:33'),
(349, '2024-10-24 10:21:50'),
(350, '2024-10-24 10:22:33'),
(351, '2024-10-24 10:22:41'),
(352, '2024-10-24 10:23:34'),
(353, '2024-10-24 10:23:48'),
(354, '2024-10-24 10:28:46'),
(355, '2024-10-24 10:28:58'),
(356, '2024-10-24 10:29:04'),
(357, '2024-10-24 10:29:13'),
(358, '2024-10-24 10:30:08'),
(359, '2024-10-24 10:38:50'),
(360, '2024-10-24 10:40:30'),
(361, '2024-10-24 10:42:31'),
(362, '2024-10-24 10:44:24'),
(363, '2024-10-24 10:54:03'),
(364, '2024-10-24 10:54:14'),
(365, '2024-10-24 11:00:04'),
(366, '2024-10-24 11:04:41'),
(367, '2024-10-24 11:08:02'),
(368, '2024-10-24 11:09:07'),
(369, '2024-10-24 11:12:48'),
(370, '2024-10-24 11:13:26'),
(371, '2024-10-24 11:13:45'),
(372, '2024-10-24 11:13:59'),
(373, '2024-10-24 12:58:02'),
(374, '2024-10-24 13:04:09'),
(375, '2024-10-24 13:07:17'),
(376, '2024-10-24 13:07:47'),
(377, '2024-10-24 13:09:04'),
(378, '2024-10-24 13:09:50'),
(379, '2024-10-24 13:10:07'),
(380, '2024-10-24 13:10:56'),
(381, '2024-10-24 13:11:04'),
(382, '2024-10-24 13:13:37'),
(383, '2024-10-24 13:13:47'),
(384, '2024-10-24 13:14:15'),
(385, '2024-10-24 13:18:31'),
(386, '2024-10-24 13:21:33'),
(387, '2024-10-24 13:24:22'),
(388, '2024-10-24 13:26:23'),
(389, '2024-10-24 13:27:37'),
(390, '2024-10-24 13:28:02'),
(391, '2024-10-24 13:28:08'),
(392, '2024-10-24 13:30:25'),
(393, '2024-10-24 13:31:17'),
(394, '2024-10-24 13:33:35'),
(395, '2024-10-24 13:35:49'),
(396, '2024-10-24 13:36:34'),
(397, '2024-10-24 13:38:19'),
(398, '2024-10-24 13:39:04'),
(399, '2024-10-24 13:39:48'),
(400, '2024-10-24 13:39:59'),
(401, '2024-10-24 13:40:20'),
(402, '2024-10-24 13:43:06'),
(403, '2024-10-24 13:44:28'),
(404, '2024-10-24 13:44:36'),
(405, '2024-10-24 14:00:58'),
(406, '2024-10-24 14:03:58'),
(407, '2024-10-24 14:04:45'),
(408, '2024-10-24 14:08:45'),
(409, '2024-10-24 14:09:04'),
(410, '2024-10-24 14:13:07'),
(411, '2024-10-24 14:13:34'),
(412, '2024-10-24 14:13:43'),
(413, '2024-10-24 14:15:56'),
(414, '2024-10-24 14:17:00'),
(415, '2024-10-24 14:17:10'),
(416, '2024-10-24 14:25:46'),
(417, '2024-10-24 14:25:58'),
(418, '2024-10-24 14:26:42'),
(419, '2024-10-24 14:26:54'),
(420, '2024-10-24 14:32:26'),
(421, '2024-10-24 14:35:13'),
(422, '2024-10-24 14:35:15'),
(423, '2024-10-24 14:35:30'),
(424, '2024-10-24 14:35:59'),
(425, '2024-10-24 14:42:41'),
(426, '2024-10-24 14:43:00'),
(427, '2024-10-24 14:44:20'),
(428, '2024-10-24 14:44:29'),
(429, '2024-10-24 14:45:18'),
(430, '2024-10-24 14:45:25'),
(431, '2024-10-24 14:46:23'),
(432, '2024-10-24 14:51:10'),
(433, '2024-10-24 14:59:39'),
(434, '2024-10-24 15:00:06'),
(435, '2024-10-24 15:00:20'),
(436, '2024-10-24 15:00:32'),
(437, '2024-10-24 15:00:46'),
(438, '2024-10-24 15:02:02'),
(439, '2024-10-24 15:02:19'),
(440, '2024-10-24 15:02:29'),
(441, '2024-10-24 15:06:33'),
(442, '2024-10-24 15:06:59'),
(443, '2024-10-24 15:08:09'),
(444, '2024-10-24 15:08:40'),
(445, '2024-10-24 15:09:10'),
(446, '2024-10-24 15:14:44'),
(447, '2024-10-24 15:14:53'),
(448, '2024-10-24 15:15:11'),
(449, '2024-10-24 15:23:14'),
(450, '2024-10-24 15:26:03'),
(451, '2024-10-24 15:26:12'),
(452, '2024-10-24 15:27:30'),
(453, '2024-10-24 15:29:14'),
(454, '2024-10-24 15:29:37'),
(455, '2024-10-24 15:29:43'),
(456, '2024-10-24 15:30:22'),
(457, '2024-10-24 15:30:28'),
(458, '2024-10-24 15:32:01'),
(459, '2024-10-24 15:34:41'),
(460, '2024-10-24 15:40:55'),
(461, '2024-10-24 19:16:18'),
(462, '2024-10-24 19:56:06'),
(463, '2024-10-24 20:03:25'),
(464, '2024-10-24 20:13:42'),
(465, '2024-10-24 20:18:26'),
(466, '2024-10-24 20:18:47'),
(467, '2024-10-24 20:20:32'),
(468, '2024-10-24 20:22:42'),
(469, '2024-10-24 20:22:54'),
(470, '2024-10-24 20:22:56'),
(471, '2024-10-24 20:22:56'),
(472, '2024-10-24 20:22:56'),
(473, '2024-10-24 20:22:56'),
(474, '2024-10-24 20:23:30'),
(475, '2024-10-24 20:25:48'),
(476, '2024-10-24 20:42:35'),
(477, '2024-10-24 21:00:50'),
(478, '2024-10-24 21:03:58'),
(479, '2024-10-24 21:04:49'),
(480, '2024-10-24 21:06:52'),
(481, '2024-10-24 21:08:13'),
(482, '2024-10-24 21:09:27'),
(483, '2024-10-24 21:09:37'),
(484, '2024-10-24 21:12:25'),
(485, '2024-10-24 21:19:21'),
(486, '2024-10-24 21:20:06'),
(487, '2024-10-24 21:26:58'),
(488, '2024-10-24 21:27:51'),
(489, '2024-10-24 21:30:59'),
(490, '2024-10-24 21:34:04'),
(491, '2024-10-24 21:37:15'),
(492, '2024-10-24 21:38:17'),
(493, '2024-10-24 21:39:42'),
(494, '2024-10-24 21:41:30'),
(495, '2024-10-24 21:42:58'),
(496, '2024-10-24 21:43:14');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `cover_image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `content`, `link`, `cover_image`, `created_at`) VALUES
(4, 'Menteri Keuangan Apresiasi Kekompakan Kementerian Lembaga Perbaiki Kinerja Desentralisasi', NULL, 'https://www.kemenkeu.go.id/informasi-publik/publikasi/berita-utama/seminar-internasional-desentralisasi-fiskal-20-%281%29', '66fa1272b45fb.jpg', '2024-09-30 02:52:34'),
(5, 'Kunci Perempuan Bisa Jadi Pemimpin Menurut Menkeu Sri Mulyani', NULL, 'https://www.kemenkeu.go.id/informasi-publik/publikasi/berita-utama/Kunci-Perempuan-Jadi-Pemimpin-Menurut-Menkeu', '66fa12c18ec42.jpg', '2024-09-30 02:53:53'),
(7, 'Perkuat Kerja Sama dengan Arab Saudi, Wamenkeu Suahasil Sampaikan Peran Strategis Indonesia dalam IsDB', NULL, 'https://www.kemenkeu.go.id/informasi-publik/publikasi/berita-utama/Peran-Strategis-Indonesia-dalam-IsDB', '66fcea3839a15.jpg', '2024-10-02 06:37:44'),
(8, 'Hadiri Governor Business Roundtable AIIB, Wamenkeu Sampaikan Hal Ini', NULL, 'https://www.kemenkeu.go.id/informasi-publik/publikasi/berita-utama/Governor-Business-Roundtable-AIIB', '66fcea5bd82ee.jpg', '2024-10-02 06:38:19'),
(9, 'Wamenkeu Suahasil Nazara Adakan Pertemuan Bilateral dengan Presiden AIIB', NULL, 'https://www.kemenkeu.go.id/informasi-publik/publikasi/berita-utama/Wamenkeu-Suahasil-bertemu-Presiden-AIIB', '66fcea9238c70.jpg', '2024-10-02 06:39:14');

-- --------------------------------------------------------

--
-- Table structure for table `pengaduan`
--

CREATE TABLE `pengaduan` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `nik` varchar(16) NOT NULL,
  `email` varchar(255) NOT NULL,
  `nomorhp` varchar(15) NOT NULL,
  `kategori` varchar(50) NOT NULL,
  `pesan` text NOT NULL,
  `terima_email` tinyint(1) NOT NULL,
  `terima_sms` tinyint(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pengajuan_cuti`
--

CREATE TABLE `pengajuan_cuti` (
  `id_pengajuan` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `perihal` varchar(255) NOT NULL,
  `jenis_surat` varchar(255) NOT NULL,
  `nomor_surat` varchar(255) NOT NULL,
  `tanggal_pengajuan` timestamp NOT NULL DEFAULT current_timestamp(),
  `tanggal_akhir_cuti` date DEFAULT NULL,
  `tanggal_mulai_cuti` date DEFAULT NULL,
  `lama_cuti` varchar(100) DEFAULT NULL,
  `keterangan` enum('Disetujui','Ditolak') DEFAULT NULL,
  `bidang_penerima` varchar(100) NOT NULL,
  `nama_penerima` varchar(100) NOT NULL,
  `ttd` varchar(100) NOT NULL,
  `username` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pengajuan_cuti`
--

INSERT INTO `pengajuan_cuti` (`id_pengajuan`, `nama`, `perihal`, `jenis_surat`, `nomor_surat`, `tanggal_pengajuan`, `tanggal_akhir_cuti`, `tanggal_mulai_cuti`, `lama_cuti`, `keterangan`, `bidang_penerima`, `nama_penerima`, `ttd`, `username`) VALUES
(63, 'Citra Dewi', 'cuti tahunan', 'SICT', 'SICT/1/WPJ243/2025', '2024-10-23 04:08:01', '2024-10-25', '2024-10-24', '1', 'Disetujui', 'Bidang Sekretaris Kanwil', 'Sari', '', 'citra'),
(66, 'Citra Dewi', 'cuti tahunan', 'SICT', 'SICT/2/WPJ243/2025', '2024-10-23 04:14:43', '2024-10-24', '2024-10-23', '1', 'Disetujui', 'Bidang Sekretaris Kanwil', 'Sari', '', 'citra'),
(67, 'Citra Dewi', 'cuti sakit', 'SICS', 'SICS/1/WPJ243/2025', '2024-10-23 04:15:12', '2024-10-25', '2024-10-24', '2', 'Disetujui', 'Bidang PEP', 'Andi', 'C:\\xampp\\htdocs\\pep/signatures/ttd_67.png', 'citra'),
(68, 'Amel', 'cuti tahunan', 'SICT', 'SICT/3/WPJ243/2025', '2024-10-24 14:04:42', '2024-10-25', '2024-10-24', '1', 'Disetujui', 'Bidang PEP', 'Andi', '', 'user'),
(69, 'Andini Rizki', 'cuti tahunan', 'SICT', 'SICT/4/WPJ243/2025', '2024-10-24 14:38:08', '2024-10-25', '2024-10-25', '1', 'Disetujui', 'Bidang Sekretaris Kanwil', 'Sari', '', 'amel.the.series');

-- --------------------------------------------------------

--
-- Table structure for table `persetujuan_cuti`
--

CREATE TABLE `persetujuan_cuti` (
  `id_persetujuan` int(11) NOT NULL,
  `id_pengajuan` int(11) DEFAULT NULL,
  `ttd` varchar(255) DEFAULT NULL,
  `foto_tanda_terima` varchar(255) DEFAULT NULL,
  `bidang_penerima` varchar(100) NOT NULL,
  `nama_penerima` varchar(100) NOT NULL,
  `status` enum('Disetujui','Ditolak') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pustaka`
--

CREATE TABLE `pustaka` (
  `id` int(11) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `kategori` enum('Pendaftaran','Ekstentifikasi','Penilaian') NOT NULL,
  `cover_image` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pustaka`
--

INSERT INTO `pustaka` (`id`, `judul`, `kategori`, `cover_image`, `link`, `created_at`) VALUES
(4, 'Materi A', 'Pendaftaran', '66fa13213d723.jpg', 'https://www.careers-page.com/freeportindonesia/job/QV9348R8', '2024-09-30 02:55:29'),
(5, 'Materi B', 'Pendaftaran', '66fa1334ce029.jpg', 'https://magang.kemenkeu.go.id/in/home', '2024-09-30 02:55:48'),
(6, 'Materi C', 'Pendaftaran', '66fa134611cf5.jpg', 'https://www.youtube.com/watch?v=gqUQbjsYZLQ', '2024-09-30 02:56:06'),
(7, 'Materi D', 'Ekstentifikasi', '66fa135bd749b.jpg', 'https://www.kemenkeu.go.id/profile/agenda', '2024-09-30 02:56:27'),
(8, 'Materi PDF', 'Penilaian', '66fa138d3b679.jpg', 'https://www.kemenkeu.go.id/profile/agenda', '2024-09-30 02:57:17');

-- --------------------------------------------------------

--
-- Table structure for table `quick_links`
--

CREATE TABLE `quick_links` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `icon` varchar(255) DEFAULT 'fas fa-link'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `username` varchar(15) NOT NULL,
  `password` varchar(8) NOT NULL,
  `nama` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`username`, `password`, `nama`) VALUES
('user', 'user', 'Amel'),
('amelia', 'password', 'Amelia Rizki Andini'),
('budi', 'password', 'Budi Santoso'),
('citra', 'password', 'Citra Dewi'),
('dina', 'password', 'Dina Lestari'),
('eko', 'password', 'Eko Prasetyo'),
('fajar', 'password', 'Fajar Nugroho'),
('gita', 'password', 'Gita Putri'),
('hadi', 'password', 'Hadi Saputra'),
('ika', 'password', 'Ika Wulandari'),
('joko', 'password', 'Joko Setiawan'),
('iameliara', '$2y$10$0', 'Amelia Rizki Andini'),
('iameliara', '$2y$10$H', 'Amelia Rizki Andini'),
('iameliara', '$2y$10$r', 'Amelia Rizki Andini'),
('iameliara', '$2y$10$D', 'Amelia Rizki Andini'),
('iameliara', '$2y$10$R', 'Imas Chaerul'),
('prabto123', '$2y$10$n', 'Suprapto'),
('amelia05', '$2y$10$k', 'Amelia Rizki Andini'),
('ameleazz', '$2y$10$H', 'Amelia Rizki '),
('user123', '$2y$10$2', 'Amelia Rizki'),
('amel.the.series', 'amel05', 'Andini Rizki');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `galeri`
--
ALTER TABLE `galeri`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kunjungan`
--
ALTER TABLE `kunjungan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pengajuan_cuti`
--
ALTER TABLE `pengajuan_cuti`
  ADD PRIMARY KEY (`id_pengajuan`),
  ADD KEY `id` (`id_pengajuan`);

--
-- Indexes for table `persetujuan_cuti`
--
ALTER TABLE `persetujuan_cuti`
  ADD PRIMARY KEY (`id_persetujuan`),
  ADD KEY `id_pengajuan` (`id_pengajuan`);

--
-- Indexes for table `pustaka`
--
ALTER TABLE `pustaka`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quick_links`
--
ALTER TABLE `quick_links`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `galeri`
--
ALTER TABLE `galeri`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `kunjungan`
--
ALTER TABLE `kunjungan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=497;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `pengajuan_cuti`
--
ALTER TABLE `pengajuan_cuti`
  MODIFY `id_pengajuan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT for table `persetujuan_cuti`
--
ALTER TABLE `persetujuan_cuti`
  MODIFY `id_persetujuan` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pustaka`
--
ALTER TABLE `pustaka`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `quick_links`
--
ALTER TABLE `quick_links`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `persetujuan_cuti`
--
ALTER TABLE `persetujuan_cuti`
  ADD CONSTRAINT `fk_pengajuan` FOREIGN KEY (`id_pengajuan`) REFERENCES `pengajuan_cuti` (`id_pengajuan`),
  ADD CONSTRAINT `persetujuan_cuti_ibfk_1` FOREIGN KEY (`id_pengajuan`) REFERENCES `pengajuan_cuti` (`id_pengajuan`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
