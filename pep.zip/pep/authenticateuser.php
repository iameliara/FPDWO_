<?php
session_start();

$servername = "localhost";
$db_username = "root"; // username untuk koneksi database
$password = "";
$dbname = "db_pep";

// Membuat koneksi ke database
$conn = new mysqli($servername, $db_username, $password, $dbname);

// Mengecek koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Mengambil data dari form
$form_username = $_POST['username'];
$form_password = $_POST['password'];

// Mencari pengguna di basis data
$sql = "SELECT * FROM user WHERE username = ?";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    die('Prepare failed: ' . htmlspecialchars($conn->error));
}
$stmt->bind_param("s", $form_username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Username ditemukan, cek password
    $row = $result->fetch_assoc();
    if ($form_password === $row['password']) { // Bandingkan password teks biasa
        // Password benar, set session dengan username dari form
        $_SESSION['session_username'] = $form_username;
        header("Location: home.php");
        exit();
    } else {
        // Password salah
        echo "Password salah";
    }
} else {
    // Username tidak ditemukan
    echo "Username tidak ditemukan";
}

$stmt->close();
$conn->close();
?>
