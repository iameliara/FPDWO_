
    <?php 

        $data_uri = $_POST['foto'];
        $encoded_image = explode(",", $data_uri)[1];
        $decoded_image = base64_decode($encoded_image);
        file_put_contents("signature.png", $decoded_image);
?>