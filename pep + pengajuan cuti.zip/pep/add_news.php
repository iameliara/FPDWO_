<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.html");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_pengaduan";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $link = $_POST['link'];

    // File upload
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["cover_image"]["name"]);

    if (move_uploaded_file($_FILES["cover_image"]["tmp_name"], $target_file)) {
        $cover_image = basename($_FILES["cover_image"]["name"]);

        // Insert news into database
        $sql = "INSERT INTO news (title, link, cover_image) VALUES ('$title', '$link', '$cover_image')";
        if ($conn->query($sql) === TRUE) {
            echo "News added successfully!";
        } else {
            echo "Error: " . $conn->error;
        }
    } else {
        echo "Failed to upload image.";
    }
}

$conn->close();
?>
