<?php
// Database connection details
$servername = "localhost";
$username = "root"; // Sesuaikan dengan username database Anda
$password = ""; // Sesuaikan dengan password database Anda
$dbname = "db_pengaduan";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$nama = $_POST['nama'];
$nik = $_POST['nik'];
$email = $_POST['email'];
$nomorhp = $_POST['nomorhp'];
$kategori = $_POST['kategori'];
$kategori_lainnya = isset($_POST['kategori_lainnya']) ? $_POST['kategori_lainnya'] : '';
$pesan = $_POST['pesan'];
$terima_email = isset($_POST['emailCheckbox']) ? 1 : 0;
$terima_sms = isset($_POST['smsCheckbox']) ? 1 : 0;

// If the user has entered a custom category, insert it into the 'kategori' table
if ($kategori === 'lainnya' && !empty($kategori_lainnya)) {
    $stmt = $conn->prepare("INSERT INTO kategori (nama_kategori) VALUES (?)");
    $stmt->bind_param("s", $kategori_lainnya);
    if ($stmt->execute()) {
        $kategori = $kategori_lainnya;
    }
    $stmt->close();
}

// Prepare and bind
$stmt = $conn->prepare("INSERT INTO pengaduan (nama, nik, email, nomorhp, kategori, pesan, terima_email, terima_sms) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssssii", $nama, $nik, $email, $nomorhp, $kategori, $pesan, $terima_email, $terima_sms);

// Execute the statement
$response = array();
if ($stmt->execute()) {
    $response['success'] = true;
    $response['message'] = "Pengaduan berhasil disimpan.";
} else {
    $response['success'] = false;
    $response['message'] = "Error: " . $stmt->error;
}

// Close connections
$stmt->close();
$conn->close();

// Return JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>
