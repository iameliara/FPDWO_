<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Materi Seksi Penilaian</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <style>
        .pustaka-item {
            margin-bottom: 20px;
        }
        .pustaka-item img {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #003f72;" fixed-top>
    <div class="container">
        <a class="navbar-brand" href="#top">
            <img src="images/Group 1.png" class="logo" alt="Logo Kementerian Keuangan" loading="lazy" style="width: 250px; height: auto;">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
    </div>
</nav>
   
    <div class="container mt-5">
        <h1 class="mb-4">Galeri Pustaka - Penilaian</h1>

        
        <div class="row">
            <?php
            // Koneksi database
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "db_pep";

            $conn = new mysqli($servername, $username, $password, $dbname);

            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Query untuk mengambil data pustaka kategori Penilaian
            $sql = "SELECT * FROM pustaka WHERE kategori = 'Penilaian' ORDER BY created_at DESC";
            $result = $conn->query($sql);

            // Fungsi untuk memotong teks jika terlalu panjang
            function truncateText($text, $length = 100) {
                return (strlen($text) > $length) ? substr($text, 0, $length) . '...' : $text;
            }
            ?>
            <?php
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    ?>
                    <div class="col-md-4 pustaka-item">
                        <div class="card">
                            <img src="uploads/<?php echo htmlspecialchars($row['cover_image']); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($row['judul']); ?>">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo htmlspecialchars($row['judul']); ?></h5>
                                <a href="<?php echo htmlspecialchars($row['link']); ?>" class="btn btn-primary" target="_blank">Lihat Materi</a>
                            </div>
                        </div>
                    </div>
                    <?php
                }
            } else {
                echo "<p>Tidak ada data pustaka untuk kategori Penilaian.</p>";
            }
            ?>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <!-- Footer -->
    <footer class="text-center text-light bg-dark p-2 mt-4">
      <p class="mt-3">Website by AMELIA</p>
    </footer>

    <!-- jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="js/jquery-3.5.1.slim.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <!-- Fontawesome JS Online-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/js/all.min.js"></script>
    <!-- Fontawesome JS Offline -->
    <script src="fontawesome/all.min.js"></script>
    <!-- My Script -->
    <script src="js/main.js"></script>
  </body>
</html>

<?php
$conn->close();
?>
