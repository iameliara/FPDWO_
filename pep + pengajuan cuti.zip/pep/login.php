<?php
session_start();

// Koneksi ke database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_pengaduan";

$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Proses login
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Query untuk memeriksa kredensial
    $sql = "SELECT * FROM users WHERE username='$username'"; // Hanya ambil pengguna berdasarkan username
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        // Verifikasi password
        if (password_verify($password, $row['password'])) { // Pastikan password di-hash
            $_SESSION['admin'] = $username; // Atur session admin
            header("Location: admin_dashboard.php"); // Redirect ke dashboard
            exit();
        } else {
            echo "<script>alert('Password salah.'); window.location.href='login.html';</script>";
        }
    } else {
        echo "<script>alert('Username tidak ditemukan.'); window.location.href='login.html';</script>";
    }
}

$conn->close();
?>
