<?php 
session_start();

// Pastikan user sudah login
if (!isset($_SESSION['session_username'])) {
    header("Location: index.html");
    exit();
}

// Aktifkan error report selama debugging
error_reporting(E_ALL);
ini_set('display_errors', '1');

// Koneksi ke database
$servername = "localhost";
$db_username = "root";
$password = "";
$dbname = "db_pep";

$conn = new mysqli($servername, $db_username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ambil username dari session
$username = $_SESSION['session_username'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validasi input
    $perihal = isset($_POST['perihal']) ? trim($_POST['perihal']) : '';
    $tanggal_mulai_cuti = isset($_POST['tanggal_mulai_cuti']) ? trim($_POST['tanggal_mulai_cuti']) : '';
    $tanggal_akhir_cuti = isset($_POST['tanggal_akhir_cuti']) ? trim($_POST['tanggal_akhir_cuti']) : '';
    $lama_cuti = isset($_POST['lama_cuti']) ? trim($_POST['lama_cuti']) : '';

    // Ambil nama pengguna
    $sql_user = "SELECT nama FROM user WHERE username = ?";
    $stmt_user = $conn->prepare($sql_user);
    if (!$stmt_user) {
        die("Query error: " . $conn->error);
    }

    $stmt_user->bind_param("s", $username);
    $stmt_user->execute();
    $result_user = $stmt_user->get_result();

    $nama = '';
    if ($result_user->num_rows > 0) {
        $row_user = $result_user->fetch_assoc();
        $nama = $row_user['nama'];
    } else {
        echo "<script>alert('User tidak ditemukan!'); window.location.href='index.html';</script>";
        exit();
    }

    // Menentukan jenis surat
    $jenis_surat = match ($perihal) {
        'cuti tahunan' => 'SICT',
        'cuti sakit' => 'SICS',
        'cuti alasan penting' => 'SICAP',
        default => 'Unknown',
    };

    // Ambil nomor surat terakhir
    $sql_last_number = "SELECT nomor_surat FROM pengajuan_cuti WHERE jenis_surat = ? ORDER BY id_pengajuan DESC LIMIT 1";
    $stmt_last_number = $conn->prepare($sql_last_number);
    if (!$stmt_last_number) {
        die("Query error: " . $conn->error);
    }

    $stmt_last_number->bind_param("s", $jenis_surat);
    $stmt_last_number->execute();
    $result_last_number = $stmt_last_number->get_result();

    $last_number = 0;
    if ($result_last_number->num_rows > 0) {
        $row = $result_last_number->fetch_assoc();
        // Perbaikan regex untuk menangkap angka ID pengajuan
        preg_match('/^' . preg_quote($jenis_surat, '/') . '\/(\d+)\/WPJ243\/2025$/', $row['nomor_surat'], $matches);
        if (isset($matches[1])) {
            $last_number = (int)$matches[1];  // Konversi ke integer
        }
    }

    $new_number = $last_number + 1;
    $nomor_surat = "$jenis_surat/$new_number/WPJ243/2025";

    // Simpan data ke database
    $sql = "INSERT INTO pengajuan_cuti (username, nama, perihal, jenis_surat, nomor_surat, tanggal_mulai_cuti, tanggal_akhir_cuti, lama_cuti) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Query error: " . $conn->error);
    }

    $stmt->bind_param("ssssssss", $username, $nama, $perihal, $jenis_surat, $nomor_surat, $tanggal_mulai_cuti, $tanggal_akhir_cuti, $lama_cuti);

    if ($stmt->execute()) {
        echo "<script>alert('Pengajuan cuti berhasil!'); window.location.href='pengajuancuti.php';</script>"; 
    } else {
        echo "<script>alert('Error: " . $stmt->error . "'); window.location.href='pengajuancuti.php';</script>";
    }

    // Tutup statement dan koneksi
    $stmt->close();
    $stmt_user->close();
    $stmt_last_number->close();
}

$conn->close();
?>
