<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.html");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_pengaduan";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Log visit
$sql = "INSERT INTO kunjungan (timestamp) VALUES (NOW())";
$conn->query($sql);

// Fetch data for charts
$sql_kunjungan = "SELECT DATE(timestamp) as date, COUNT(*) as count FROM kunjungan GROUP BY DATE(timestamp)";
$kunjungan_result = $conn->query($sql_kunjungan);
$kunjungan_data = [];
while($row = $kunjungan_result->fetch_assoc()) {
    $kunjungan_data[] = $row;
}

$sql_pengaduan = "SELECT kategori, COUNT(*) as count FROM pengaduan GROUP BY kategori";
$pengaduan_result = $conn->query($sql_pengaduan);
$pengaduan_data = [];
while($row = $pengaduan_result->fetch_assoc()) {
    $pengaduan_data[] = $row;
}

// Handle Event Management (Add Event)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_event'])) {
    $event_name = $_POST['event_name'];
    $event_date = $_POST['event_date'];
    $event_time = $_POST['event_time'];
    $description = $_POST['description'];

    $sql = "INSERT INTO events (event_name, event_date, event_time, description) 
            VALUES ('$event_name', '$event_date', '$event_time', '$description')";
    $conn->query($sql);
}

// Handle News Management (Add/Edit/Delete News)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_news'])) {
        // Add news
        $title = $_POST['title'];
        $link = $_POST['link'];
        $target_dir = "uploads/";
        $temp_file = $_FILES["cover_image"]["tmp_name"];
        $target_file = $target_dir . uniqid() . ".jpg";

        $standard_width = 800;
        $standard_height = 600;

        if (resizeAndCropImage($temp_file, $target_file, $standard_width, $standard_height)) {
            $cover_image = basename($target_file);
            $sql = "INSERT INTO news (title, link, cover_image) VALUES ('$title', '$link', '$cover_image')";
            $conn->query($sql);
        }
    } elseif (isset($_POST['edit_news'])) {
        // Edit news
        $id = $_POST['id'];
        $title = $_POST['title'];
        $link = $_POST['link'];
        $sql = "UPDATE news SET title='$title', link='$link' WHERE id=$id";
        if (!empty($_FILES["cover_image"]["name"])) {
            $target_file = "uploads/" . basename($_FILES["cover_image"]["name"]);
            move_uploaded_file($_FILES["cover_image"]["tmp_name"], $target_file);
            $cover_image = basename($_FILES["cover_image"]["name"]);
            $sql = "UPDATE news SET title='$title', link='$link', cover_image='$cover_image' WHERE id=$id";
        }
        $conn->query($sql);
    }
}

if (isset($_GET['delete'])) {
    // Delete news
    $id = $_GET['delete'];
    $sql = "DELETE FROM news WHERE id=$id";
    $conn->query($sql);
}

// Handle Pustaka Management (Add/Edit/Delete Pustaka)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_pustaka']) || isset($_POST['edit_pustaka'])) {
        $judul = $_POST['judul'];
        $link = $_POST['link'];
        $kategori = $_POST['kategori'];
        $id = isset($_POST['id']) ? $_POST['id'] : null;

        $target_dir = "uploads/";
        $temp_file = $_FILES["cover_image"]["tmp_name"];
        $target_file = $target_dir . uniqid() . ".jpg";

        $standard_width = 800;
        $standard_height = 600;

        if (resizeAndCropImage($temp_file, $target_file, $standard_width, $standard_height)) {
            $cover_image = basename($target_file);

            if ($id) {
                // Edit existing pustaka
                $sql = "UPDATE pustaka SET judul='$judul', link='$link', kategori='$kategori', cover_image='$cover_image' WHERE id=$id";
            } else {
                // Add new pustaka
                $sql = "INSERT INTO pustaka (judul, link, cover_image, kategori) VALUES ('$judul', '$link', '$cover_image', '$kategori')";
            }
            $conn->query($sql);
        }
    }
}

if (isset($_GET['delete_pustaka'])) {
    $id = $_GET['delete_pustaka'];
    $sql = "DELETE FROM pustaka WHERE id=$id";
    $conn->query($sql);
}

if (isset($_GET['edit_pustaka'])) {
    $id = $_GET['edit_pustaka'];
    $result = $conn->query("SELECT * FROM pustaka WHERE id=$id");
    $edit_pustaka = $result->fetch_assoc();
}

// Handle Galeri Management (Add/Edit/Delete Galeri)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_galeri']) || isset($_POST['edit_galeri'])) {
        $judul = $_POST['judul_galeri'];
        $link = $_POST['link_galeri'];
        $id = isset($_POST['id']) ? $_POST['id'] : null;

        if (isset($_FILES["gambar_galeri"]) && $_FILES["gambar_galeri"]["error"] == UPLOAD_ERR_OK) {
            $target_dir = "uploads/";
            $file_extension = strtolower(pathinfo($_FILES["gambar_galeri"]["name"], PATHINFO_EXTENSION));
            $target_file = $target_dir . uniqid() . "." . $file_extension;

            $allowed_types = array('jpg', 'jpeg', 'png', 'gif');
            if (in_array($file_extension, $allowed_types)) {
                if (resizeAndCropImage($_FILES["gambar_galeri"]["tmp_name"], $target_file, 800, 600)) {
                    $gambar = basename($target_file);

                    if ($id) {
                        // Edit existing galeri
                        $sql = "UPDATE galeri SET judul='$judul', link='$link', gambar='$gambar' WHERE id=$id";
                    } else {
                        // Add new galeri
                        $sql = "INSERT INTO galeri (judul, link, gambar) VALUES ('$judul', '$link', '$gambar')";
                    }

                    if ($conn->query($sql) === TRUE) {
                        echo "<script>alert('Data berhasil disimpan');</script>";
                    } else {
                        echo "<script>alert('Error: " . $conn->error . "');</script>";
                    }
                } else {
                    echo "<script>alert('Gagal mengupload file');</script>";
                }
            } else {
                echo "<script>alert('Hanya file JPG, JPEG, PNG, dan GIF yang diizinkan');</script>";
            }
        } else {
            // Jika tidak ada file yang diunggah, hanya update judul dan link
            if ($id) {
                $sql = "UPDATE galeri SET judul='$judul', link='$link' WHERE id=$id";
                if ($conn->query($sql) === TRUE) {
                    echo "<script>alert('Data berhasil diperbarui');</script>";
                } else {
                    echo "<script>alert('Error: " . $conn->error . "');</script>";
                }
            } else {
                echo "<script>alert('Silakan pilih gambar untuk ditambahkan');</script>";
            }
        }
    }
}

if (isset($_GET['delete_galeri'])) {
    $id = $_GET['delete_galeri'];
    $sql = "DELETE FROM galeri WHERE id=$id";
    $conn->query($sql);
}

if (isset($_GET['edit_galeri'])) {
    $id = $_GET['edit_galeri'];
    $result = $conn->query("SELECT * FROM galeri WHERE id=$id");
    $edit_galeri = $result->fetch_assoc();
}

function resizeAndCropImage($sourcePath, $targetPath, $targetWidth, $targetHeight) {
    return move_uploaded_file($sourcePath, $targetPath);
}

if (isset($_FILES["gambar_galeri"]) && $_FILES["gambar_galeri"]["error"] !== UPLOAD_ERR_OK) {
    $upload_errors = array(
        UPLOAD_ERR_INI_SIZE => "The uploaded file exceeds the upload_max_filesize directive in php.ini",
        UPLOAD_ERR_FORM_SIZE => "The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form",
        UPLOAD_ERR_PARTIAL => "The uploaded file was only partially uploaded",
        UPLOAD_ERR_NO_FILE => "No file was uploaded",
        UPLOAD_ERR_NO_TMP_DIR => "Missing a temporary folder",
        UPLOAD_ERR_CANT_WRITE => "Failed to write file to disk",
        UPLOAD_ERR_EXTENSION => "A PHP extension stopped the file upload"
    );
    $error_message = isset($upload_errors[$_FILES["gambar_galeri"]["error"]]) ? $upload_errors[$_FILES["gambar_galeri"]["error"]] : "Unknown upload error";
    echo "<script>alert('Upload error: " . $error_message . "');</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .chart-container {
            position: relative;
            height: 300px;
            width: 100%;
        }
        .chart-title {
            text-align: center;
            font-weight: bold;
            margin-bottom: 10px;
        }
        .nav-pills .nav-link.active {
            background-color: #007bff;
        }
        .card-img-top {
            width: 100%;
            height: 200px; /* Sesuaikan dengan rasio yang Anda inginkan */
            object-fit: cover;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <nav class="col-md-2 d-none d-md-block bg-light sidebar">
                <div class="sidebar-sticky">
                    <h2 class="mt-2">Admin Dashboard</h2>
                    <ul class="nav flex-column nav-pills" id="v-pills-tab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="v-pills-home-tab" data-toggle="pill" href="#v-pills-home" role="tab">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="v-pills-events-tab" data-toggle="pill" href="#v-pills-events" role="tab">Manage Events</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="v-pills-news-tab" data-toggle="pill" href="#v-pills-news" role="tab">Manage News</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="v-pills-pustaka-tab" data-toggle="pill" href="#v-pills-pustaka" role="tab">Manage Pustaka</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="v-pills-galeri-tab" data-toggle="pill" href="#v-pills-galeri" role="tab">Manage Galeri</a>
                        </li>
                    </ul>
                    <a href="logout.php" class="btn btn-danger mt-3">Logout</a>
                </div>
            </nav>

            <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
                <div class="tab-content" id="v-pills-tabContent">
                    <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel">
                        <h2>Dashboard Overview</h2>
                        <div class="row">
                            <div class="col-md-8">
                                <div class="chart-title">Data Kunjungan</div>
                                <div class="chart-container">
                                    <canvas id="barChart"></canvas>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="chart-title">Data Pengaduan</div>
                                <div class="chart-container">
                                    <canvas id="donutChart"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="tab-pane fade" id="v-pills-events" role="tabpanel">
                        <h2>Manage Events</h2>
                        <form action="admin_dashboard.php" method="POST">
                            <div class="form-group">
                                <label for="event_name">Event Name:</label>
                                <input type="text" class="form-control" id="event_name" name="event_name" required>
                            </div>
                            <div class="form-group">
                                <label for="event_date">Event Date:</label>
                                <input type="date" class="form-control" id="event_date" name="event_date" required>
                            </div>
                            <div class="form-group">
                                <label for="event_time">Event Time:</label>
                                <input type="time" class="form-control" id="event_time" name="event_time" required>
                            </div>
                            <div class="form-group">
                                <label for="description">Description:</label>
                                <textarea class="form-control" id="description" name="description" rows="4" required></textarea>
                            </div>
                            <button type="submit" name="add_event" class="btn btn-primary">Add Event</button>
                        </form>
                    </div>
                    
                    <div class="tab-pane fade" id="v-pills-news" role="tabpanel">
                        <h2>Manage News</h2>
                        <form action="admin_dashboard.php" method="POST" enctype="multipart/form-data">
                            <input type="hidden" name="id" value="<?php echo isset($edit_news['id']) ? $edit_news['id'] : ''; ?>">
                            <div class="form-group">
                                <label for="title">Title:</label>
                                <input type="text" class="form-control" id="title" name="title" value="<?php echo isset($edit_news['title']) ? $edit_news['title'] : ''; ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="link">Link:</label>
                                <input type="text" class="form-control" id="link" name="link" value="<?php echo isset($edit_news['link']) ? $edit_news['link'] : ''; ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="cover_image">Cover Image:</label>
                                <input type="file" class="form-control" id="cover_image" name="cover_image">
                            </div>
                            <button type="submit" name="<?php echo isset($edit_news) ? 'edit_news' : 'add_news'; ?>" class="btn btn-primary">Submit</button>
                        </form>
                        
                        <h3 class="mt-4">News List</h3>
                        <div class="row">
                            <?php
                            $news_result = $conn->query("SELECT * FROM news ORDER BY created_at DESC");
                            while ($row = $news_result->fetch_assoc()) { ?>
                                <div class="col-md-4 mb-3">
                                    <div class="card">
                                        <img class="card-img-top" src="uploads/<?php echo $row['cover_image']; ?>" alt="<?php echo $row['title']; ?>">
                                        <div class="card-body">
                                            <h5 class="card-title"><?php echo $row['title']; ?></h5>
                                            <a href="<?php echo $row['link']; ?>" class="btn btn-primary btn-sm">Read More</a>
                                            <a href="admin_dashboard.php?edit=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                            <a href="admin_dashboard.php?delete=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm">Delete</a>
                                        </div>
                                    </div>
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                    
                    <div class="tab-pane fade" id="v-pills-pustaka" role="tabpanel">
                        <h2>Manage Pustaka</h2>
                        <form action="admin_dashboard.php" method="POST" enctype="multipart/form-data">
                            <input type="hidden" name="id" value="<?php echo isset($edit_pustaka['id']) ? $edit_pustaka['id'] : ''; ?>">
                            <div class="form-group">
                                <label for="judul">Judul Materi:</label>
                                <input type="text" class="form-control" id="judul" name="judul" value="<?php echo isset($edit_pustaka['judul']) ? $edit_pustaka['judul'] : ''; ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="link">Link Materi:</label>
                                <input type="url" class="form-control" id="link" name="link" value="<?php echo isset($edit_pustaka['link']) ? $edit_pustaka['link'] : ''; ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="cover_image">Cover Materi:</label>
                                <input type="file" class="form-control" id="cover_image" name="cover_image">
                            </div>
                            <div class="form-group">
                                <label for="kategori">Kategori:</label>
                                <select class="form-control" id="kategori" name="kategori" required>
                                    <option value="">Pilih Kategori</option>
                                    <option value="Pendaftaran" <?php echo (isset($edit_pustaka['kategori']) && $edit_pustaka['kategori'] == 'Pendaftaran') ? 'selected' : ''; ?>>Pendaftaran</option>
                                    <option value="Ekstentifikasi" <?php echo (isset($edit_pustaka['kategori']) && $edit_pustaka['kategori'] == 'Ekstentifikasi') ? 'selected' : ''; ?>>Ekstentifikasi</option>
                                    <option value="Penilaian" <?php echo (isset($edit_pustaka['kategori']) && $edit_pustaka['kategori'] == 'Penilaian') ? 'selected' : ''; ?>>Penilaian</option>
                                </select>
                            </div>
                            <button type="submit" name="<?php echo isset($edit_pustaka) ? 'edit_pustaka' : 'add_pustaka'; ?>" class="btn btn-primary">Submit</button>
                        </form>
                        
                        <h3 class="mt-4">Daftar Pustaka</h3>
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Judul</th>
                                        <th>Kategori</th>
                                        <th>Link</th>
                                        <th>Cover</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $pustaka_result = $conn->query("SELECT * FROM pustaka ORDER BY created_at DESC");
                                    while ($row = $pustaka_result->fetch_assoc()) { ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($row['judul']); ?></td>
                                            <td><?php echo htmlspecialchars($row['kategori']); ?></td>
                                            <td><a href="<?php echo htmlspecialchars($row['link']); ?>" target="_blank">Lihat</a></td>
                                            <td><img src="uploads/<?php echo htmlspecialchars($row['cover_image']); ?>" alt="<?php echo htmlspecialchars($row['judul']); ?>" style="width: 50px; height: auto;"></td>
                                            <td>
                                                <a href="admin_dashboard.php?edit_pustaka=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                                <a href="admin_dashboard.php?delete_pustaka=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus pustaka ini?')">Hapus</a>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="v-pills-galeri" role="tabpanel">
                        <h2>Manage Galeri</h2>
                        <form action="admin_dashboard.php" method="POST" enctype="multipart/form-data">
                            <input type="hidden" name="id" value="<?php echo isset($edit_galeri['id']) ? $edit_galeri['id'] : ''; ?>">
                            <div class="form-group">
                                <label for="judul_galeri">Judul:</label>
                                <input type="text" class="form-control" id="judul_galeri" name="judul_galeri" value="<?php echo isset($edit_galeri['judul']) ? $edit_galeri['judul'] : ''; ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="link_galeri">Link:</label>
                                <input type="url" class="form-control" id="link_galeri" name="link_galeri" value="<?php echo isset($edit_galeri['link']) ? $edit_galeri['link'] : ''; ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="gambar_galeri">Gambar:</label>
                                <input type="file" class="form-control" id="gambar_galeri" name="gambar_galeri" accept="image/jpeg,image/png,image/gif" <?php echo isset($edit_galeri) ? '' : 'required'; ?>>
                                <small class="form-text text-muted">Hanya file JPG, JPEG, PNG, dan GIF yang diizinkan.</small>
                            </div>
                            <button type="submit" name="<?php echo isset($edit_galeri) ? 'edit_galeri' : 'add_galeri'; ?>" class="btn btn-primary">Submit</button>
                        </form>
                        
                        <h3 class="mt-4">Daftar Galeri</h3>
                        <div class="row">
                            <?php
                            $galeri_result = $conn->query("SELECT * FROM galeri ORDER BY created_at DESC");
                            if (!$galeri_result) {
                                echo "<script>alert('Error: " . $conn->error . "');</script>";
                            } else {
                                echo "<script>console.log('Jumlah data: " . $galeri_result->num_rows . "');</script>";
                                if ($galeri_result->num_rows > 0) {
                                    while ($row = $galeri_result->fetch_assoc()) { ?>
                                        <div class="col-md-4 mb-3">
                                            <div class="card">
                                                <img class="card-img-top" src="uploads/<?php echo htmlspecialchars($row['gambar']); ?>" alt="<?php echo htmlspecialchars($row['judul']); ?>">
                                                <div class="card-body">
                                                    <h5 class="card-title"><?php echo htmlspecialchars($row['judul']); ?></h5>
                                                    <a href="<?php echo htmlspecialchars($row['link']); ?>" class="btn btn-primary btn-sm" target="_blank">Lihat</a>
                                                    <a href="admin_dashboard.php?edit_galeri=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                                    <a href="admin_dashboard.php?delete_galeri=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus item galeri ini?')">Hapus</a>
                                                </div>
                                            </div>
                                        </div>
                                    <?php }
                                } else {
                                    echo "<p>Tidak ada data galeri.</p>";
                                }
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script>
        var barCtx = document.getElementById('barChart').getContext('2d');
        var colors = ['rgba(255, 99, 132, 1)', 'rgba(255, 206, 86, 1)', 'rgba(54, 162, 235, 1)', 'rgba(75, 192, 192, 1)', 'rgba(153, 102, 255, 1)', 'rgba(255, 159, 64, 1)'];
        var barChart = new Chart(barCtx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode(array_column($kunjungan_data, 'date')); ?>,
                datasets: [{
                    label: 'Visits',
                    data: <?php echo json_encode(array_column($kunjungan_data, 'count')); ?>,
                    backgroundColor: colors,
                    borderColor: colors,
                    borderWidth: 1
                }]
            },
            options: {
                plugins: { legend: { display: false } },
                scales: { y: { beginAtZero: true } }
            }
        });

        var donutCtx = document.getElementById('donutChart').getContext('2d');
        var donutChart = new Chart(donutCtx, {
            type: 'doughnut',
            data: {
                labels: <?php echo json_encode(array_column($pengaduan_data, 'kategori')); ?>,
                datasets: [{
                    data: <?php echo json_encode(array_column($pengaduan_data, 'count')); ?>,
                    backgroundColor: ['rgba(255, 206, 86, 1)', 'rgba(255, 99, 132, 1)', 'rgba(54, 162, 235, 1)'],
                    borderColor: ['rgba(255, 206, 86, 1)', 'rgba(255, 99, 132, 1)', 'rgba(54, 162, 235, 1)'],
                    borderWidth: 1
                }]
            },
            options: { plugins: { legend: { display: true } }, responsive: true, maintainAspectRatio: false }
        });

        document.querySelector('form').addEventListener('submit', function(e) {
            var fileInput = document.getElementById('gambar_galeri');
            var submitButton = document.querySelector('button[type="submit"]');
            
            if (submitButton.name === 'add_galeri' && fileInput.files.length === 0) {
                e.preventDefault();
                alert('Silakan pilih gambar untuk ditambahkan');
            }
        });
    </script>
</body>
</html>

<?php
$conn->close();
?>
