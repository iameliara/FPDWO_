<?php
// Include the file that fetches news data
$news_items = include 'fetch_news.php';

// Tambahkan koneksi database dan query untuk events
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_pengaduan";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query untuk semua events
$sql = "SELECT * FROM events";
$result = $conn->query($sql);

$events = [];
while ($row = $result->fetch_assoc()) {
    $events[] = [
        'title' => $row['event_name'],
        'start' => $row['event_date'] . 'T' . $row['event_time'],
        'description' => $row['description']
    ];
}

// Query untuk events hari ini
$today = date('Y-m-d');
$sql_today = "SELECT * FROM events WHERE event_date = '$today' ORDER BY event_time";
$result_today = $conn->query($sql_today);

$events_today = [];
while ($row = $result_today->fetch_assoc()) {
    $events_today[] = $row;
}

$conn->close();

// Fungsi untuk mengubah ukuran dan memotong gambar
function resizeAndCropImage($sourcePath, $targetPath, $targetWidth, $targetHeight) {
    list($sourceWidth, $sourceHeight, $sourceType) = getimagesize($sourcePath);
    
    switch ($sourceType) {
        case IMAGETYPE_JPEG:
            $sourceImage = imagecreatefromjpeg($sourcePath);
            break;
        case IMAGETYPE_PNG:
            $sourceImage = imagecreatefrompng($sourcePath);
            break;
        case IMAGETYPE_GIF:
            $sourceImage = imagecreatefromgif($sourcePath);
            break;
        default:
            return false;
    }
    
    $targetImage = imagecreatetruecolor($targetWidth, $targetHeight);
    
    $sourceRatio = $sourceWidth / $sourceHeight;
    $targetRatio = $targetWidth / $targetHeight;
    
    if ($sourceRatio > $targetRatio) {
        $crop_width = $sourceHeight * $targetRatio;
        $crop_height = $sourceHeight;
        $crop_x = ($sourceWidth - $crop_width) / 2;
        $crop_y = 0;
    } else {
        $crop_width = $sourceWidth;
        $crop_height = $sourceWidth / $targetRatio;
        $crop_x = 0;
        $crop_y = ($sourceHeight - $crop_height) / 2;
    }
    
    imagecopyresampled($targetImage, $sourceImage, 0, 0, $crop_x, $crop_y, $targetWidth, $targetHeight, $crop_width, $crop_height);
    
    switch ($sourceType) {
        case IMAGETYPE_JPEG:
            imagejpeg($targetImage, $targetPath, 90);
            break;
        case IMAGETYPE_PNG:
            imagepng($targetImage, $targetPath, 9);
            break;
        case IMAGETYPE_GIF:
            imagegif($targetImage, $targetPath);
            break;
    }
    
    imagedestroy($sourceImage);
    imagedestroy($targetImage);
    
    return true;
}
?>

<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>PEP DJP Jatim II</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="fontawesome/all.min.css">
    <link rel="shortcut icon" href="images/fav2.ico">
    <link rel="stylesheet" href="css/style.css">
    <!-- FullCalendar CSS -->
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@5.10.1/main.min.css" rel="stylesheet" />

    <!-- FullCalendar JS -->
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.10.1/main.min.js"></script>

    <style>
        .reminder-container {
            background-color: #f8f9fa;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin: 20px 0;
            padding: 20px;
        }
        .reminder-title {
            color: #003f72;
            font-size: 1.5em;
            font-weight: bold;
            margin-bottom: 15px;
            text-align: center;
        }
        .reminder-event {
            background-color: #fff;
            border-left: 5px solid #003f72;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
            margin-bottom: 15px;
            padding: 15px;
        }
        .reminder-event-title {
            color: #003f72;
            font-size: 1.2em;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .reminder-event-time {
            color: #6c757d;
            font-size: 0.9em;
            margin-bottom: 5px;
        }
        .reminder-event-description {
            color: #495057;
            font-size: 1em;
        }

        .card-img-overlay {
            background: rgba(0,0,0,0.2);
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .card:hover .card-img-overlay {
            opacity: 1;
        }

        .card-img-overlay .btn {
            transition: all 0.3s ease;
            transform: scale(0.8);
        }

        .card:hover .card-img-overlay .btn {
            transform: scale(1);
        }

        .news-image-container {
            position: relative;
            overflow: hidden;
        }

        .news-image-container img {
            transition: filter 0.3s ease;
        }

        .news-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .news-image-container:hover .news-overlay {
            opacity: 1;
        }

        .news-image-container:hover img {
            filter: blur(3px);
        }

        .news-overlay .btn {
            transition: all 0.3s ease;
            transform: scale(0.8);
        }

        .news-image-container:hover .news-overlay .btn {
            transform: scale(1);
        }

        .card-img-top {
            width: 100%;
            height: 200px; /* Sesuaikan dengan rasio yang Anda inginkan */
            object-fit: cover;
        }

        .quick-link {
            background-color: #003f72;
            color: white;
            height: 150px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            transition: all 0.3s ease;
            border-radius: 10px;
            padding: 20px;
        }
        .quick-link:hover {
            background-color: #005a9e;
            text-decoration: none;
            color: white;
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .quick-link i {
            font-size: 40px;
            margin-bottom: 10px;
        }
        .quick-link span {
            font-size: 16px;
            font-weight: bold;
        }

        .aturan-item {
            background-color: #f8f9fa;
            border: 1px solid #e9ecef;
            border-radius: 5px;
            padding: 15px;
            display: flex;
            align-items: center;
            transition: all 0.3s ease;
            height: 80px;
            text-decoration: none;
            color: #333;
        }

        .aturan-item:hover {
            background-color: #e9ecef;
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            text-decoration: none;
            color: #333;
        }

        .aturan-item i {
            font-size: 24px;
            margin-right: 15px;
            color: #003f72;
        }

        .aturan-item span {
            font-size: 16px;
            font-weight: bold;
        }

        .bg-info {
            background-color: #17a2b8 !important;
        }

        marquee {
            font-size: 18px;
            line-height: 1.5;
        }

        .galeri-slider {
            margin-bottom: 30px;
        }

        .galeri-item {
            padding: 0 10px;
        }

        .galeri-item img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            transition: transform 0.3s ease;
        }

        .galeri-item img:hover {
            transform: scale(1.05);
        }

        .galeri-slider {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
        }

        .galeri-item {
            width: 30%;
            margin-bottom: 20px;
            position: relative;
            overflow: hidden;
        }

        .galeri-item img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            transition: transform 0.3s ease;
        }

        .galeri-item:hover img {
            transform: scale(1.1);
        }

        .galeri-caption {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            background-color: rgba(0, 0, 0, 0.7);
            color: white;
            padding: 10px;
            text-align: center;
        }

        .galeri-caption h5 {
            margin: 0;
            font-size: 16px;
        }

        @media (max-width: 768px) {
            .galeri-item {
                width: 48%;
            }
        }

        @media (max-width: 576px) {
            .galeri-item {
                width: 100%;
            }
        }

        .nav-item .fa-user-circle {
            color: white;
            transition: color 0.3s ease;
        }

        .nav-item:hover .fa-user-circle {
            color: #f8f9fa;
        }

        #bannerCarousel {
            max-height: 33vh; /* Set maximum height to 1/3 of viewport height */
            overflow: hidden;
        }
        #bannerCarousel .carousel-item {
            height: 33vh;
        }
        #bannerCarousel .carousel-item img {
            object-fit: cover;
            object-position: center;
            height: 100%;
            width: 100%;
        }
        .carousel-caption {
            background-color: rgba(0, 0, 0, 0.5);
            padding: 10px;
            border-radius: 5px;
        }
    </style>
</head>
<body id="top">

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #003f72;" fixed-top>
    <div class="container">
        <a class="navbar-brand" href="#top">
            <img src="images/Group 1.png" class="logo" alt="Logo Kementerian Keuangan" loading="lazy" style="width: 250px; height: auto;">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item"><a class="nav-link" href="#top">Beranda</a></li>
                <li class="nav-item"><a class="nav-link" href="#berita">Berita</a></li>
                <li class="nav-item"><a class="nav-link" href="#infoUMKM">Pustaka</a></li>
                <li class="nav-item"><a class="nav-link" href="#galeri">Galeri</a></li>
                <li class="nav-item"><a class="nav-link" href="#kontak">Kalender</a></li>
                <li class="nav-item">
                    <a class="nav-link" href="login.html" title="Login Admin">
                        <i class="fas fa-user-circle fa-lg"></i>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="jumbotron" style="padding-top: 5px; padding-bottom: 50px;">
    <div class="container text-center">
        <h1 style="font-size: 2.0em;">BIDANG PENDAFTARAN, EKSTENTIFIKASI, DAN PENILAIAN<br>KANTOR WILAYAH DIREKTORAT JENDERAL PAJAK<br>JAWA TIMUR II</h1>
        <a href="detail.html" class="btn btn-sm btn-info">Selengkapnya..</a>
    </div>
</div>

<!-- Banner Carousel -->
<div class="container-fluid px-0">
    <div id="bannerCarousel" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
            <!-- First Slide -->
            <div class="carousel-item active">
                <img src="images/banner1.jpg" class="d-block w-100" alt="Banner 1">
                <div class="carousel-caption d-none d-md-block">
                    <h5>Kunjungi Kemenkeu Learning Center Sekarang!</h5>
                </div>
            </div>
            <!-- Second Slide -->
            <div class="carousel-item">
                <img src="images/banner2.png" class="d-block w-100" alt="Banner 2">
                <div class="carousel-caption d-none d-md-block">
                    <h5>Belajar Lebih Mudah Dengan Kemenkeu Learning Center</h5>
                </div>
            </div>
            <!-- Add more slides if needed -->
        </div>
        <a class="carousel-control-prev" href="#bannerCarousel" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#bannerCarousel" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
</div>

<!-- Reminder Section -->
<?php if (!empty($events_today)): ?>
<div class="container">
    <div class="reminder-container">
        <div class="reminder-title">Agenda Hari Ini</div>
        <?php foreach ($events_today as $event): ?>
        <div class="reminder-event">
            <div class="reminder-event-title"><?php echo htmlspecialchars($event['event_name']); ?></div>
            <div class="reminder-event-time">
                <i class="fas fa-clock"></i> <?php echo date('H:i', strtotime($event['event_time'])); ?>
            </div>
            <div class="reminder-event-description">
                <?php echo htmlspecialchars($event['description']); ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<!-- Berita Section -->
<section id="berita" class="pb-4">
    <div class="container mb-2">
        <div class="row pt-4 mb-4">
            <div class="col text-center">
                <h2>Berita</h2>
            </div>
        </div>

        <div class="row">
            <?php if (!empty($news_items)): ?>
                <?php 
                $count = 0;
                foreach ($news_items as $news): 
                    if ($count % 3 == 0 && $count != 0): ?>
                        </div><div class="row mt-4">
                    <?php endif; ?>
                    <div class="col-md-4 col-sm-6 mb-4">
                        <div class="card">
                            <div class="news-image-container">
                                <?php
                                $image_path = "uploads/" . $news['cover_image'];
                                if (!file_exists($image_path)) {
                                    $image_path = "path/to/default/image.jpg"; // Ganti dengan path ke gambar default
                                }
                                ?>
                                <img src="<?php echo $image_path; ?>" alt="Cover Image" class="card-img-top">
                                <div class="news-overlay">
                                    <a href="<?php echo $news['link']; ?>" class="btn btn-sm btn-info">Selengkapnya</a>
                                </div>
                            </div>
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $news['title']; ?></h5>
                            </div>
                        </div>
                    </div>
                <?php 
                $count++;
                if ($count >= 6) break; // Hentikan setelah 6 item
                endforeach; ?>
            <?php else: ?>
                <div class="col-12">
                    <p class="text-center">Tidak ada berita tersedia.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Dasar Aturan Section -->
<section id="dasarAturan" class="pb-4">
    <div class="container mb-2">
        <div class="row pt-4 mb-4">
            <div class="col text-center">
                <h2>Dasar Aturan</h2>
            </div>
        </div>
        <div class="row">
            <?php
            $aturan_items = [
                ['title' => 'UU KUP', 'icon' => 'fas fa-book', 'url' => 'https://example.com/uu-kup'],
                ['title' => 'UU PPh', 'icon' => 'fas fa-percentage', 'url' => 'https://example.com/uu-pph'],
                ['title' => 'UU PPN', 'icon' => 'fas fa-shopping-cart', 'url' => 'https://example.com/uu-ppn'],
                ['title' => 'UU PBB', 'icon' => 'fas fa-home', 'url' => 'https://example.com/uu-pbb'],
                ['title' => 'UU BPHTB', 'icon' => 'fas fa-file-contract', 'url' => 'https://example.com/uu-bphtb'],
                ['title' => 'UU Cukai', 'icon' => 'fas fa-smoking', 'url' => 'https://example.com/uu-cukai'],
                ['title' => 'UU Kepabeanan', 'icon' => 'fas fa-ship', 'url' => 'https://example.com/uu-kepabeanan'],
                ['title' => 'UU PPSP', 'icon' => 'fas fa-gavel', 'url' => 'https://example.com/uu-ppsp']
            ];

            foreach ($aturan_items as $index => $item) {
                if ($index % 4 == 0 && $index != 0) {
                    echo '</div><div class="row">';
                }
                echo '<div class="col-md-3 col-sm-6 mb-4">';
                echo '<a href="' . $item['url'] . '" class="aturan-item" target="_blank">';
                echo '<i class="' . $item['icon'] . '"></i>';
                echo '<span>' . $item['title'] . '</span>';
                echo '</a>';
                echo '</div>';
            }
            ?>
        </div>
    </div>
</section>

<!-- Materi per subbidang. -->
<section id="infoUMKM" class="pb-4">
    <div class="container mb-2">
        <div class="row pt-4 mb-4">
        <div class="col text-center">
                <h2>Materi Per Seksi</h2>
            </div>
        </div>

        <div class="row">
            <div class="col-md-4 col-sm-12">
                <figure>
                    <img src="images/pendaftaran.jpeg" alt="Pendaftaran" class="img-fluid">
                    <figcaption>
                        <h3>Pendaftaran</h3>
                        <a href="galeri.php" class="btn btn-sm btn-info">Lihat</a>
                    </figcaption>
                </figure>
            </div>
            <div class="col-md-4 col-sm-12">
                <figure>
                    <img src="images/ektentifikasi.jpeg" alt="Ekstentifikasi" class="img-fluid">
                    <figcaption>
                        <h3>Ekstentifikasi</h3>
                        <a href="galeri2.php" class="btn btn-sm btn-info">Lihat</a>
                    </figcaption>
                </figure>
            </div>
            <div class="col-md-4 col-sm-12">
                <figure>
                    <img src="images/penilaian.png" alt="Penilaian" class="img-fluid">
                    <figcaption>
                        <h3>Penilaian</h3>
                        <a href="galeri3.php" class="btn btn-sm btn-info">Lihat</a>
                    </figcaption>
                </figure>
            </div>
        </div>
    </div>
</section>

<!-- Quick Links Section -->
<section id="quickLinks" class="pb-4">
    <div class="container mb-2">
        <div class="row pt-4 mb-4">
            <div class="col text-center">
                <h2>Tautan Cepat</h2>
            </div>
        </div>
        <div class="row">
            <?php
            $quick_links = [
                ['title' => 'DRM', 'icon' => 'fas fa-graduation-cap', 'url' => 'https://elearning.kemenkeu.go.id/'],
                ['title' => 'DMP', 'icon' => 'fas fa-chart-line', 'url' => 'https://sakti.kemenkeu.go.id/'],
                ['title' => 'Approveb', 'icon' => 'fas fa-database', 'url' => 'https://span.kemenkeu.go.id/'],
                ['title' => 'Apportal', 'icon' => 'fas fa-tachometer-alt', 'url' => 'https://spanint.kemenkeu.go.id/'],
                ['title' => 'SIDJP', 'icon' => 'fas fa-sync', 'url' => 'https://e-rekon-lk.kemenkeu.go.id/'],
                ['title' => 'SIKKA', 'icon' => 'fas fa-building', 'url' => 'https://www.siman.kemenkeu.go.id/'],
                ['title' => 'Mandor', 'icon' => 'fas fa-boxes', 'url' => 'https://simakbmn.kemenkeu.go.id/']
            ];

            foreach ($quick_links as $link) {
                echo '<div class="col-md-3 col-sm-6 mb-4">';
                echo '<a href="' . $link['url'] . '" class="quick-link d-block" target="_blank">';
                echo '<i class="' . $link['icon'] . '"></i>';
                echo '<span>' . $link['title'] . '</span>';
                echo '</a>';
                echo '</div>';
            }
            ?>
        </div>
    </div>
</section>

<!-- Galeri Section -->
<section id="galeri" class="pb-4">
    <div class="container mb-2">
        <div class="row pt-4 mb-4">
            <div class="col text-center">
                <h2>Galeri</h2>
            </div>
        </div>
        <div class="galeri-slider">
            <?php
            // Buat koneksi database baru
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "db_pengaduan";

            $conn_galeri = new mysqli($servername, $username, $password, $dbname);

            // Periksa koneksi
            if ($conn_galeri->connect_error) {
                die("Connection failed: " . $conn_galeri->connect_error);
            }

            $galeri_result = $conn_galeri->query("SELECT * FROM galeri ORDER BY created_at DESC LIMIT 6");
            if ($galeri_result && $galeri_result->num_rows > 0) {
                while ($row = $galeri_result->fetch_assoc()) { ?>
                    <div class="galeri-item">
                        <a href="<?php echo htmlspecialchars($row['link']); ?>" target="_blank">
                            <img src="uploads/<?php echo htmlspecialchars($row['gambar']); ?>" alt="<?php echo htmlspecialchars($row['judul']); ?>" class="img-fluid">
                            <div class="galeri-caption">
                                <h5><?php echo htmlspecialchars($row['judul']); ?></h5>
                            </div>
                        </a>
                    </div>
                <?php }
            } else {
                echo "<p>Tidak ada data galeri.</p>";
            }

            // Tutup koneksi
            $conn_galeri->close();
            ?>
        </div>
    </div>
</section>

<!-- Running Text -->
<div class="container-fluid bg-info py-2 mb-4">
    <marquee behavior="scroll" direction="left" scrollamount="5">
        <span class="text-white font-weight-bold">Selamat Bekerja dan Sehat Selalu!</span>
    </marquee>
</div>

<!-- Kalender Section -->
<section id="kalender" class="pb-4">
    <div class="container">
        <div class="row pt-4 mb-4">
            <div class="col text-center">
                <h2>Kalender</h2>
            </div>
        </div>
        <div class="row justify-content-center align-items-center text-center">
            <div class="col-md-6">
                <div id="calendar"></div> <!-- Placeholder for the calendar -->
            </div>
        </div>
    </div>
</section>

<!-- Kontak Section -->
<section id="kontak" class="text-white pb-4">
    <div class="container">
        <div class="row pt-4 mb-4">
            <div class="col text-center">
                <h2>Kontak</h2>
            </div>
        </div>
        <div class="row justify-content-center">
            <div id="sosmed" class="col-md-3 mb-4 text-center">
                <h3>Media Sosial</h3>
                <div class="row mb-2">
                    <div class="col">
                        <a href=""><i class="fab fa-fw fa-facebook fa-2x mr-2"></i></a>
                        <a href=""><i class="fab fa-fw fa-instagram fa-2x mr-2"></i></a>
                        <a href=""><i class="fab fa-fw fa-twitter fa-2x mr-2"></i></a>
                        <a href=""><i class="fab fa-fw fa-youtube fa-2x mr-2"></i></a>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <a href=""><i class="fab fa-fw fa-whatsapp fa-2x mr-2"></i></a>
                        <a href=""><i class="fab fa-fw fa-line fa-2x mr-2"></i></a>
                        <a href=""><i class="fab fa-fw fa-telegram fa-2x mr-2"></i></a>
                        <a href=""><i class="fas fa-fw fa-envelope fa-2x mr-2"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Footer -->
<footer class="text-center text-light bg-dark p-2">
    <p class="mt-3">Website by Amelia</p>
</footer>

<a id="backtotop" href="#top"><img src="images/angle-up.svg" alt=""></a>

<script src="js/jquery-3.5.1.slim.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="fontawesome/all.min.js"></script>
<script src="js/main.js"></script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        var calendarEl = document.getElementById('calendar');

        var calendar = new FullCalendar.Calendar(calendarEl, {
            initialView: 'dayGridMonth',
            locale: 'id',
            headerToolbar: {
                left: 'prev,next today',
                center: 'title',
                right: 'dayGridMonth'
            },
            events: <?php echo json_encode($events); ?>,
            eventClick: function(info) {
                alert('Event: ' + info.event.title + '\nDescription: ' + info.event.extendedProps.description);
            },
            navLinks: true,
            editable: false,
            dayMaxEvents: true
        });

        calendar.render();
    });
</script>

<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css"/>
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick-theme.css"/>
<script type="text/javascript" src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
<script>
$(document).ready(function(){
    $('.galeri-slider').slick({
        slidesToShow: 3,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        responsive: [
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 2
                }
            },
            {
                breakpoint: 576,
                settings: {
                    slidesToShow: 1
                }
            }
        ]
    });
});
</script>

</body>
</html>