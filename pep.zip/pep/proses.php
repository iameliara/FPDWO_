<?php 

    $data_uri = $_POST['foto'];
    $encoded_image = explode(",", $data_uri)[1];
    $decoded_image = base64_decode($encoded_image);

    // Buat folder signatures jika belum ada
    if (!file_exists('signatures')) {
        mkdir('signatures', 0755, true);
    }

    // Inisialisasi nomor file
    $i = 87;
    
    // Tentukan nama file dengan penomoran dalam folder signatures
    while (file_exists("signatures/signature{$i}.png")) {
        $i++;
    }
    $file_name = "signatures/signature{$i}.png";

    // Simpan file dengan nama yang telah ditentukan
    file_put_contents($file_name, $decoded_image);
?>
