<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_pep";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle Update Bidang Penerima
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $bidang_penerima = $_POST['bidang_penerima'];

    // Query untuk memperbarui bidang penerima
    $sql = "UPDATE persetujuan_cuti SET bidang_penerima = '$bidang_penerima' WHERE id = $id_pengajuan";
    
    if ($conn->query($sql) === TRUE) {
        // Redirect ke admin_dashboard.php setelah berhasil
        header("Location: admin_dashboard.php");
        exit();
    } else {
        echo "<script>alert('Error: " . $conn->error . "');</script>";