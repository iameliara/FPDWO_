<?php
session_start();

// Koneksi ke database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_pengaduan";

$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Proses login
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Query untuk memeriksa kredensial
    $sql = "SELECT * FROM users WHERE username='$username' AND password='$password'"; // Pastikan untuk menggunakan hashing password di sini
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Jika kredensial benar, simpan informasi pengguna di session
        $row = $result->fetch_assoc();
        $_SESSION['session_username'] = $username; // Atur session admin
        $_SESSION['session_id'] = $row['id_user']; // Simpan ID pengguna
        $_SESSION['session_password'] = $row['password'];
        header("Location: home.php"); // Redirect ke halaman home
        exit();
    } else {
        echo "<script>alert('Username atau password salah.'); window.location.href='login.html';</script>";
    }
}

$conn->close();

// Mengatur cookie jika sesi sudah dimulai
if (isset($_SESSION['username'])) {
    setcookie("username", $_SESSION['username'], time() + 3600, "/"); // Set cookie untuk 1 jam
}

// Cek apakah sesi sudah dimulai
if (session_id() == '') {
    echo "Sesi belum dimulai.";
} else {
    echo "Sesi sudah dimulai. ID Sesi: " . session_id();
}

// Membaca cookie
if (isset($_COOKIE['username'])) {
    echo "<br>Username dari cookie: " . htmlspecialchars($_COOKIE['username']);
} else {
    echo "<br>Cookie username tidak ditemukan.";
}

// Menghapus cookie (jika diperlukan)
if (isset($_POST['logout'])) {
    setcookie("username", "", time() - 3600, "/"); // Menghapus cookie
    session_unset();
    session_destroy();
    echo "<br>Cookie username telah dihapus.";
}
?>
